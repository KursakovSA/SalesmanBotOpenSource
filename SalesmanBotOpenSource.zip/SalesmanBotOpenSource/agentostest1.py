import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from agno.agent import Agent
from agno.models.ollama import Ollama
# import chat
from agno.os import AgentOS  # Модуль AgentOS от Agno

# 1. Инициализация FastAPI приложения
app = FastAPI(
    title="Agno + Ollama Chatbot API",
    description="Скелетный AI-чатбот с использованием AgentOS, FastAPI и Uvicorn",
    version="1.0.0"
)

# 2. Определение Pydantic моделей для валидации запросов/ответов


class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None


class ChatResponse(BaseModel):
    response: str
    session_id: str | None = None


# 3. Настройка ИИ Агента через Agno с поддержкой локального Ollama
chat_agent = Agent(
    model=Ollama(id="ministral-3:3b"),  # Укажите вашу локальную модель Ollama
    description="Вы — полезный и лаконичный ИИ-ассистент.",
    #add_history_to_messages=True,  # Включаем автоматическое сохранение контекста
    markdown=True
)

# 4. Регистрация Агента в экосистеме AgentOS
# Это автоматически создает стандартные эндпоинты Agno на базе FastAPI (например, для UI)
agent_os = AgentOS(agents=[chat_agent])
app.include_router(agent_os.router, prefix="/api/v1/os")

# 5. Кастомный эндпоинт FastAPI для классического чата


@app.post("/api/v1/chat", response_model=ChatResponse)
async def chat_endpoint(payload: ChatRequest):
    """
    Эндпоинт для отправки сообщения боту и получения ответа.
    """
    # Вызываем агента асинхронно. Контекст сохраняется по session_id
    agent_response = chat_agent.run(
        message=payload.message,
        session_id=payload.session_id
    )

    return ChatResponse(
        response=agent_response.content,
        session_id=payload.session_id
    )

# 6. Дополнительный эндпоинт для проверки статуса сервиса


@app.get("/health")
async def health_check():
    return {"status": "healthy", "model": chat_agent.model.id}

# 7. Запуск через Uvicorn при прямом вызове файла
if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
