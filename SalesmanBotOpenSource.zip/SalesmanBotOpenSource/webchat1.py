# origin - 01.06.2026, last edit - 02.06.2026
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import chat


app = FastAPI()  # настройка FastAPI

app.add_middleware(  # Разрешаем запросы с вашего сайта (CORS)
    CORSMiddleware,
    # allow_origins=["https://kazprom.com", "http://localhost:8000"],
    allow_origins=["*"],
    allow_credentials=False,
    # allow_methods=["POST", "GET"],
    # allow_headers=["Content-Type"],
    allow_methods=["*"],
    allow_headers=["*"],
)

agent = chat.get_agent()


class Query(BaseModel):  # Модель данных для входящего запроса
    text: str


@app.get("/")
def read_root():
    return {"status": "Agno FastAPI service is running"}


@app.post("/chat")
async def chat_endpoint(query: Query):
    response = await agent.arun(query.text)
    return {"response": response.content}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("webchat1:app", host="0.0.0.0", port=8000, reload=True)
