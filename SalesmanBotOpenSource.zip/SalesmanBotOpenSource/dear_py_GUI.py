import dearpygui.dearpygui as dpg

dpg.create_context()
dpg.create_viewport(title='БД Менеджер', width=600, height=400)

# --- БЛОК ЗАГРУЗКИ КИРИЛЛИЧЕСКОГО ШРИФТА ---
with dpg.font_registry():
    # Загружаем стандартный шрифт Windows (Arial).
    # Для Linux/macOS укажите путь к любому вашему .ttf шрифту
    with dpg.font("C:\\Windows\\Fonts\\arial.ttf", 18) as cyrillic_font:
        # Добавляем поддержку кириллицы
        dpg.add_font_range_hint(dpg.mvFontRangeHint_Cyrillic)

# Назначаем загруженный шрифт шрифтом по умолчанию
dpg.bind_font(cyrillic_font)

with dpg.window(label="Таблица данных", width=550, height=350):
    with dpg.table(header_row=True, resizable=True, policy=dpg.mvTable_SizingStretchProp):
        # Настройка колонок
        dpg.add_table_column(label="ID")
        dpg.add_table_column(label="Имя")
        dpg.add_table_column(label="Роль")

        # Заполнение строк (в реальном коде — цикл по данным из БД)
        for row_data in [[1, "Иван", "Админ"], [2, "Ольга", "Пользователь"]]:
            with dpg.table_row():
                for item in row_data:
                    dpg.add_text(str(item))

dpg.setup_dearpygui()
dpg.show_viewport()
dpg.start_dearpygui()
dpg.destroy_context()
