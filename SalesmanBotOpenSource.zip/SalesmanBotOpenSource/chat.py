# origin - 27.05.2026, last edit - 30.05.2026
from dataclasses import dataclass, field
import log
import random
import price
from agno.models.ollama import Ollama
from agno.agent import Agent
import time


@dataclass
class Chat:
    # origin - 27.05.2026, last edit - 29.05.2026
    chatId: str = ""
    date1: str = ""
    defect: str = ""
    # modeloptions: dict = field(default_factory=dict)

    def __str__(self):
        # origin - 27.05.2026, last edit - 28.05.2026
        res = ""
        try:
            res = res+log.add_if_not_empty("chatId ", self.chatId)
            res = res+log.add_if_not_empty(", date1 ", self.date1)
            res = res+log.add_if_not_empty(", defect ", self.defect)
            # res = res+log.add_if_not_empty(", modeloptions ", str(self.modeloptions))
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except chat.__str__(self): {e}")
        return res


@staticmethod
def initchat1() -> Chat:
    # origin - 27.05.2026, last edit - 28.05.2026
    res = Chat()
    try:
        res.chatId = str(random.randint(1000, 9999))
        res.date1 = log.get_curr_datetime()
        # res.modeloptions = {
        #     "num_ctx": 4096, "temperature": 0.1, "seed": 42}
    except Exception as e:
        log.flush_except(f"except chat.initchat1(): {e}")
    return res


def get_chat(agent, chatType="PC") -> None:
    # origin - 07.05.2026, last edit - 31.05.2026
    try:
        currChat = initchat1()

        log.flush_chat(" ")
        log.flush_chat(chatType+" chatId "+currChat.chatId+". Start chat.")

        while True:
            user_input = input(chatType+" chatId "+currChat.chatId+". Вопрос: ")
            log.flush_chat(chatType+" chatId "+currChat.chatId+". Вопрос: "+user_input)

            if not user_input:
                break

            start_time = time.perf_counter()
            print("Ищу ответ...")
            response = agent.run(user_input)
            response_output = f"{chatType} chatId {currChat.chatId} Ответ: {response.content}"
            end_time = time.perf_counter()
            time_output = f" ⏱ Заняло: {end_time - start_time:.2f} сек.)"
            log.flush_chat(response_output+", "+time_output)

        log.flush_chat(chatType+" chatId "+currChat.chatId+". End chat.")
        log.flush_chat(" ")
    except Exception as e:
        log.flush_except(f"except chat.get_chat(agent): {e}")


@dataclass
class AgentParams:
    # origin - 28.05.2026, last edit - 29.05.2026
    name: str = ""
    description: str = ""
    role: str = ""
    instructions: list = field(default_factory=list)
    tools: list = field(default_factory=list)
    defect: str = ""

    def __str__(self):
        # origin - 28.05.2026, last edit - 28.05.2026
        res = ""
        try:
            res = res+log.add_if_not_empty(", name ", self.name)
            res = res+log.add_if_not_empty(", description ", self.description)
            res = res+log.add_if_not_empty(", role ", self.role)
            res = res+log.add_if_not_empty(", instructions ", str(self.instructions))
            res = res+log.add_if_not_empty(", tools ", str(self.instructions))
            res = res+log.add_if_not_empty(", defect ", self.defect)
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except agentparams.__str__(self): {e}")
        return res


@staticmethod
def initagentparams1():
    # origin - 28.05.2026, last edit - 29.05.2026
    res = AgentParams()
    try:
        res.name = "Галым"  # TOTHINK from db
        res.description = "Ты менеджер продаж металлопроката. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев"
        res.role = "менеджер продаж металлопроката"  # TOTHINK from db
        res.instructions = [
            "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров.",
            "Вы — помощник по расчету стоимости арматуры.",
            "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
            "Никогда не используй слово 'рубли' или символ '₽'.",
            "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
            "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
        ]  # TOTHINK from db
        res.tools = [price.get_product_price]  # TOTHINK from db
    except Exception as e:
        log.flush_except(f"except chat.initagentparams1(): {e}")
    return res


def get_agent() -> Agent:
    # origin - 07.05.2026, last edit - 30.05.2026
    res = Agent
    currAgentParams = initagentparams1()
    try:
        res = Agent(model=get_model(),
                    description=currAgentParams.description,
                    tools=currAgentParams.tools,
                    instructions=currAgentParams.instructions,
                    name=currAgentParams.name,
                    role=currAgentParams.role,
                    add_datetime_to_context=True,
                    add_history_to_context=False,
                    num_history_runs=3,
                    markdown=False
                    )
        return res
    except Exception as e:
        log.flush_except(f"except app.get_agent(): {e}")


def get_model() -> Ollama:
    # origin - 07.05.2026, last edit - 30.05.2026
    res = Ollama()
    try:
        # res = Ollama(id="llama3.1", options=get_model_options())
        res = Ollama(id="ministral-3:3b", options=get_model_options())
        # models qwenxxxx not work right !!!!!
    except Exception as e:
        log.flush_except(f"except app.get_model(): {e}")
    return res


@staticmethod
def get_model_options() -> dict:
    # origin - 28.05.2026, last edit - 28.05.2026
    res = {}
    try:
        res = {
            "num_ctx": 4096, "temperature": 0.1, "seed": 42}
    except Exception as e:
        log.flush_except(f"except chat.get_model_options(): {e}")
    return res


@staticmethod
def test():
    # origin - 28.05.2026, last edit - 29.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("chat.test()")

        log.flush_test("chat.initchat1.test()")
        log.flush_test("chat.initchat1(), res=" + str(initchat1()))

        log.flush_test("chat.initagentparams1.test()")
        log.flush_test("chat.initagentparams1(), res=" + str(initagentparams1()))
    except Exception as e:
        log.flush_except(f"except chat.test(): {e}")
