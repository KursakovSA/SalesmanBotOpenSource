# origin - 27.05.2026, last edit - 28.05.2026
from dataclasses import dataclass, field
import log
import random
import pricelistengine


@dataclass
class Chat:
    # origin - 27.05.2026, last edit - 27.05.2026
    chatId: str = ""
    date1: str = ""
    defect: str = ""
    # modeloptions: dict = field(default_factory=dict)

    def __init__(self):
        pass

    def __str__(self):
        # origin - 27.05.2026, last edit - 28.05.2026
        res = ""
        try:
            res = res+log.add_if_not_empty("chatId ", self.chatId)
            res = res+log.add_if_not_empty(", date1 ", self.date1)
            res = res+log.add_if_not_empty(", defect ", self.defect)
            # res = res+log.add_if_not_empty(", modeloptions ", str(self.modeloptions))
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except chat.__str__(self): {e}")
        return res


@staticmethod
def initchat1() -> Chat:
    # origin - 27.05.2026, last edit - 28.05.2026
    res = Chat()
    try:
        res.chatId = str(random.randint(1000, 9999))
        res.date1 = log.get_curr_datetime()
        # res.modeloptions = {
        #     "num_ctx": 4096, "temperature": 0.1, "seed": 42}
    except Exception as e:
        log.flush_except(f"except chat.initchat1(): {e}")
    return res


@dataclass
class AgentParams:
    # origin - 28.05.2026, last edit - 28.05.2026
    name: str = ""
    description: str = ""
    role: str = ""
    instructions: list = field(default_factory=list)
    tools: list = field(default_factory=list)
    defect: str = ""

    def __init__(self):
        pass

    def __str__(self):
        # origin - 28.05.2026, last edit - 28.05.2026
        res = ""
        try:
            res = res+log.add_if_not_empty(", name ", self.name)
            res = res+log.add_if_not_empty(", description ", self.description)
            res = res+log.add_if_not_empty(", role ", self.role)
            res = res+log.add_if_not_empty(", instructions ", str(self.instructions))
            res = res+log.add_if_not_empty(", tools ", str(self.instructions))
            res = res+log.add_if_not_empty(", defect ", self.defect)
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except agentparams.__str__(self): {e}")
        return res


@staticmethod
def initagentparams1():
    # origin - 28.05.2026, last edit - 28.05.2026
    res = AgentParams()
    try:
        res.name = "Галым"  # TOTHINK from db
        res.description = "Ты менеджер продаж металлопроката. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев"
        res.role = "менеджер продаж металлопроката"  # TOTHINK from db
        res.instructions = [
            "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров.",
            "Вы — помощник по расчету стоимости арматуры.",
            "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
            "Никогда не используй слово 'рубли' или символ '₽'.",
            "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
            "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
        ]  # TOTHINK from db
        res.tools = [pricelistengine.get_product_price]  # TOTHINK from db
    except Exception as e:
        log.flush_except(f"except chat.initagentparams1(): {e}")
    return res


@staticmethod
def get_model_options() -> dict:
    # origin - 28.05.2026, last edit - 28.05.2026
    res = {}
    try:
        res = {
            "num_ctx": 4096, "temperature": 0.1, "seed": 42}
    except Exception as e:
        log.flush_except(f"except chat.get_model_options(): {e}")
    return res


@staticmethod
def testchat():
    # origin - 27.05.2026, last edit - 28.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("chat.testchat()")
        log.flush_test("chat.initchat1(), res=" + str(initchat1()))
    except Exception as e:
        log.flush_except(f"except chat.testchat(): {e}")
        
@staticmethod
def testagentparams():
    # origin - 28.05.2026, last edit - 28.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("chat.initagentparams1.test()")
        log.flush_test("chat.initagentparams1(), res=" + str(initagentparams1()))
    except Exception as e:
        log.flush_except(f"except chat.testagentparams(): {e}")
