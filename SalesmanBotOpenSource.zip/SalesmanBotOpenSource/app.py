from agno.agent import Agent
from agno.models.ollama import Ollama
from agno.db.sqlite import SqliteDb

#agent_storage = SqliteDb(db_file="storage/agents.db")

agent = Agent(
    model=Ollama(id="llama3.1", options={"num_ctx": 4096, "temperature": 0.7}),
    description="Ты менеджер продаж металлопроката, который расспрашивает клиента покупателя о том, что ему надо. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев",
    instructions=["Всегда используй аннотации типов", "Добавляй docstrings к функциям"],
    db=SqliteDb(db_file="storage/agents.db"),  #agent_storage,
    add_history_to_context=True,
    num_history_runs=3,
    markdown=False
)

while True:
    user_input = input("\nВы: ").strip()
    
    if not user_input:
        continue

    #response = agent.print_response(user_input)
    response = agent.run(user_input)
    
    print(f"Бот: {response.content}")