from agno.agent import Agent
from agno.models.ollama import Ollama

# 1. Настройка модели
# id должен совпадать с именем модели, которую вы скачали через 'ollama pull'
model = Ollama(id="llama3.1")

# 2. Создание агента
agent = Agent(
    model=model,
    markdown=True
)

# 3. Запуск и получение ответа
agent.print_response("Привет! Как дела?")