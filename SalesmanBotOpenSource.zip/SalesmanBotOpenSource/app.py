# origin - 07.05.2026, last edit - 09.05.2026
from agno.agent import Agent
from agno.models.ollama import Ollama
from agno.db.sqlite import SqliteDb
from thefuzz import process  # Библиотека для нечеткого поиска
from agno.tools.reasoning import ReasoningTools
import time
import csv
import os

# global vars
price_list = []
rest_list = []


def main():
    # origin - 07.05.2026, last edit - 07.05.2026
    get_init()
    get_test()
    get_chat(get_agent())


def get_init() -> None:
    # origin - 07.05.2026, last edit - 07.05.2026
    try:
        get_price_list()
        get_rest_list()
    except Exception as e:
        flush_log(f"except get_init(): {e}")


def get_chat(agent) -> None:
    # origin - 07.05.2026, last edit - 09.05.2026
    try:
        while True:
            # if is_project:
            #     # print(".project")
            #     user_input = input("Вы: Сколько стоит Арматура 20 ?\n")
            # else:
            #     user_input = input("Вы: ").strip()

            user_input = input("Вы: ").strip()
            flush_log("Вы: "+user_input)

            if not user_input:
                # continue
                break

            start_time = time.perf_counter()
            print("Ищу ответ...")
            response = agent.run(user_input)
            print("Нашел ответ.")
            response_output = f"Бот: {response.content}"
            # run_response = agent.run(user_input, stream=True)
            # for chunk in run_response:
            #     # chunk.content содержит текущую порцию текста
            #     print(chunk.content, end="", flush=True)

            end_time = time.perf_counter()
            time_output = f" ⏱ Заняло: {end_time - start_time:.2f} сек.)"
            print(response_output+", "+time_output)
            flush_log(response_output+", "+time_output)
    except Exception as e:
        flush_log(f"except get_chat(): {e}")


def get_test() -> None:
    # origin - 07.05.2026, last edit - 09.05.2026
    try:
        pass
        # print(get_agent().id)
       # print(get_model())
        # print(get_price_list())
        # print(get_rest_list())

        # print(get_product_price("Арматура 20"))
        # print(get_product_price("Арматура20"))
        # print(get_product_price("Арматура 12"))
        # print(get_product_price("Молоко"))
    except Exception as e:
        flush_log(f"except get_test(): {e}")


def get_model() -> Ollama:
    # origin - 07.05.2026, last edit - 09.05.2026
    res = Ollama()
    try:
        res = Ollama(id="llama3.1", options=get_model_options(),
                     cache_response=True)
        # models qwenxxxx not work right !!!!!
    except Exception as e:
        flush_log(f"except get_model(): {e}")
    return res


def get_model_options() -> dict:
    # origin - 09.05.2026, last edit - 09.05.2026
    res = {}
    try:
        res = {
            "num_ctx": 4096, "temperature": 0.1, "seed": 42}
    except Exception as e:
        flush_log(f"except get_model_options(): {e}")
    return res


def get_agent_description() -> str:
    # origin - 07.05.2026, last edit - 09.05.2026
    res = ""
    try:
        res = "Ты менеджер продаж металлопроката. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев"
    except Exception as e:
        flush_log(f"except get_agent_description(): {e}")
    return res


def get_agent_tools() -> []:
    # origin - 07.05.2026, last edit - 09.05.2026
    res = []
    try:
        res = [get_product_price, ReasoningTools()]
    except Exception as e:
        flush_log(f"except get_agent_tools(): {e}")
    return res


# def get_agent_instructions() -> []: #TOTHINK
#     # origin - 07.05.2026, last edit - 09.05.2026
#     res = []
#     try:
#         res = [
#             "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров.",
#             "Вы — помощник по расчету стоимости арматуры.",
#             "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
#             "Никогда не используй слово 'рубли' или символ '₽'.",
#             "Если в данных видишь число, считай, что это тенге.",
#             "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
#             "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
#         ],
#     except Exception as e:
#         flush_log(f"except get_agent_instruction(): {e}")
#     return res


def get_agent() -> Agent:
    # origin - 07.05.2026, last edit - 09.05.2026
    try:
        res = Agent(model=get_model(),
                    description=get_agent_description(),
                    tools=get_agent_tools(),
                    # instructions=get_agent_instructions(),
                    instructions=[
            "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров."
            "Вы — помощник по расчету стоимости арматуры.",
            "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
            "Никогда не используй слово 'рубли' или символ '₽'.",
            "Если в данных видишь число, считай, что это тенге.",
            "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
            "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
        ],
            name=get_agent_name(),
            role=get_agent_role(),
            db=get_agent_db(),
            add_history_to_context=True,
            num_history_runs=3,
            markdown=True
        )
        return res
    except Exception as e:
        flush_log(f"except get_agent(): {e}")


def get_agent_name() -> str:  # TOTHINK
    # origin - 09.05.2026, last edit - 09.05.2026
    res = ""
    try:
        res = "Галым"  # TOTHINK
    except Exception as e:
        flush_log(f"except get_agent_name(): {e}")
    return res


def get_agent_role() -> str:  # TOTHINK
    # origin - 09.05.2026, last edit - 09.05.2026
    res = ""
    try:
        res = "менеджер продаж металлопроката"  # TOTHINK
    except Exception as e:
        flush_log(f"except get_agent_role(): {e}")
    return res


def get_agent_db() -> SqliteDb:
    # origin - 09.05.2026, last edit - 09.05.2026
    res = SqliteDb()
    try:
        res = SqliteDb(db_file="storage/agents.db")
    except Exception as e:
        flush_log(f"except get_db(): {e}")
    return res


def get_price_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 07.05.2026
    res = []
    try:
        pass
    except Exception as e:
        flush_log(f"except get_price_list(): {e}")
    return res


def get_rest_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 07.05.2026
    res = []
    try:
        pass
    except Exception as e:
        flush_log(f"except get_rest_list(): {e}")
    return res


def get_knowledge_list() -> []:  # TODO
    # origin - 08.05.2026, last edit - 07.08.2026
    res = []
    try:
        pass
    except Exception as e:
        flush_log(f"except get_knowledge_list(): {e}")
    return res


def get_product_price(product_name: str) -> str:
    # origin - 07.05.2026, last edit - 09.05.2026
    res = ""
    try:
        res = get_product_price_exact(product_name)

    # если не нашли по точному наим-ю товара, ищем по нечеткому поиску
        if not res:
            res = get_product_price_fuzz(product_name)

        if not res:
            res = "Товар " + product_name + " не найден в прайс-листе."
    except Exception as e:
        flush_log(f"get_product_price(str): {e}")
    return res


def get_product_price_exact(product_name: str) -> str:
    # origin - 09.05.2026, last edit - 09.05.2026
    res = ""
    try:
        with open('Price/price.csv', mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                if row['Name'].lower() == product_name.lower():
                    res = f"Цена товара '{row['Name']
                                          }' составляет {row['Price']}."
                # break
    except Exception as e:
        flush_log(f"get_product_price_exact(str): {e}")
    return res


# нечеткий поиск (fuzzing)
def get_product_price_fuzz(product_name: str) -> str:
    # origin - 09.05.2026, last edit - 09.05.2026
    res = ""
    try:
        # score_cutoff=70 означает, что сходство должно быть не ниже 70%
        data = list(csv.DictReader('Price/price.csv'))
        names = [row['Наименование'] for row in data]
        best_match, score = process.extractOne(
            product_name, names, score_cutoff=70) or (None, 0)

        if best_match:
            # Находим цену для найденного похожего товара
            price = next(row['Price']
                         for row in data if row['Name'] == best_match)
            res = f"Точное совпадение не найдено. Возможно, вы имели в виду '{
                best_match}'? Его цена — {price}."
    except Exception as e:
        flush_log(f"get_product_price_fuzz(str): {e}")
    return res


def is_project() -> bool:  # TODO
    # origin - 09.05.2026, last edit - 09.05.2026
    res = False
    try:
        if os.path.isfile(".project"):
            res = True
    except Exception as e:
        print(f"except is_project(): {e}")
    return res


def flush_log(str) -> None:  # TODO
    # origin - 08.05.2026, last edit - 08.05.2026
    try:
        with open('log_chat.txt', 'a', encoding='utf-8') as f:
            f.write(str + '\n')
    except Exception as e:
        print(f"except add_write_log(): {e}")


# main
if __name__ == "__main__":
    main()
