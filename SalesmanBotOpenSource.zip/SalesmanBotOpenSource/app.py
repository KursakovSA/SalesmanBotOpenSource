# origin - 07.05.2026, last edit - 11.05.2026
from agno.agent import Agent
from agno.models.ollama import Ollama
from agno.db.sqlite import SqliteDb
from thefuzz import process  # Библиотека для нечеткого поиска
# from agno.tools.reasoning import ReasoningTools
import time
from datetime import datetime
import csv
# import os

# global vars
price_list = []
rest_list = []


def main():
    # origin - 07.05.2026, last edit - 10.05.2026
    try:
        get_init()
        get_test()

        flush_log(" ")
        flush_log(get_curr_datetime()+". Start agent.")
        print("Start agent.")

        while True:
            get_chat(get_agent())
            user_input = input(get_curr_datetime()+". End agent (empty input) ?").strip()

            if not user_input:
                break

        print("End agent.")
        flush_log(get_curr_datetime()+". End agent.")
        flush_log(" ")
    except Exception as e:
        flush_log_except(f"except main(): {e}")


def get_init() -> None:
    # origin - 07.05.2026, last edit - 11.05.2026
    try:
        get_price_list()
        get_rest_list()
    except Exception as e:
        flush_log_except(f"except get_init(): {e}")


def get_chat(agent) -> None:
    # origin - 07.05.2026, last edit - 10.05.2026
    try:
        flush_log(" ")
        print("Start chat.")
        flush_log(get_curr_datetime()+". Start chat.")
        while True:
            user_input = input(get_curr_datetime()+". Вы: ").strip()
            flush_log(get_curr_datetime() + ". Вы: "+user_input)

            if not user_input:
                # continue
                break

            start_time = time.perf_counter()
            print("Ищу ответ...")
            response = agent.run(user_input)

            print("Нашел ответ.")
            response_output = f"{get_curr_datetime()}. Бот: {response.content}"
            end_time = time.perf_counter()
            time_output = f" ⏱ Заняло: {end_time - start_time:.2f} сек.)"
            print(response_output+", "+time_output)
            flush_log(response_output+", "+time_output)

        print("End chat.")
        flush_log(get_curr_datetime()+". End chat.")
        flush_log(" ")
    except Exception as e:
        flush_log_except(f"except get_chat(): {e}")


def get_test() -> None:
    # origin - 07.05.2026, last edit - 10.05.2026
    try:
        pass
        # print(get_agent().id)
       # print(get_model())
        # print(get_price_list())
        # print(get_rest_list())

        # print(get_product_price("Арматура 20"))
        # print(get_product_price("Арматура20"))
        # print(get_product_price("Арматура 12"))
        # print(get_product_price("Молоко"))
    except Exception as e:
        flush_log_except(f"except get_test(): {e}")


def get_curr_datetime() -> str:
    # origin - 10.05.2026, last edit - 11.05.2026
    res = ""
    try:
        res = f"[{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}]"
    except Exception as e:
        flush_log_except(f"except get_curr_datetime(): {e}")
    return res


def get_model() -> Ollama:
    # origin - 07.05.2026, last edit - 10.05.2026
    res = Ollama()
    try:
        # res = Ollama(id="llama3.1", options=get_model_options())
        res = Ollama(id="ministral-3:3b", options=get_model_options())
        # res = Ollama(id="llama3.1", options=get_model_options(), cache_response=True)
        # models qwenxxxx not work right !!!!!
    except Exception as e:
        flush_log_except(f"except get_model(): {e}")
    return res


def get_model_options() -> dict:
    # origin - 09.05.2026, last edit - 10.05.2026
    res = {}
    try:
        res = {
            "num_ctx": 4096, "temperature": 0.1, "seed": 42}
    except Exception as e:
        flush_log_except(f"except get_model_options(): {e}")
    return res


def get_agent_description() -> str:
    # origin - 07.05.2026, last edit - 10.05.2026
    res = ""
    try:
        res = "Ты менеджер продаж металлопроката. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев"
    except Exception as e:
        flush_log_except(f"except get_agent_description(): {e}")
    return res


def get_agent_tools() -> []:
    # origin - 07.05.2026, last edit - 10.05.2026
    res = []
    try:
        # res = [get_product_price, ReasoningTools()]
        res = [get_product_price]
    except Exception as e:
        flush_log_except(f"except get_agent_tools(): {e}")
    return res


def get_agent_instructions() -> []:  # TOTHINK
    # origin - 07.05.2026, last edit - 11.05.2026
    res = []
    try:
        res = [
            "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров.",
            "Вы — помощник по расчету стоимости арматуры.",
            "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
            "Никогда не используй слово 'рубли' или символ '₽'.",
            # "Если в данных видишь число, считай, что это тенге.",
            "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
            "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
        ],
    except Exception as e:
        flush_log_except(f"except get_agent_instructions(): {e}")
    return res


def get_agent() -> Agent:
    # origin - 07.05.2026, last edit - 11.05.2026
    res = Agent
    try:
        res = Agent(model=get_model(),
                    description=get_agent_description(),
                    tools=get_agent_tools(),
                    #             instructions=[
                    #                 "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров.",
                    #                 "Вы — помощник по расчету стоимости арматуры.",
                    #                 "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
                    #                 "Никогда не используй слово 'рубли' или символ '₽'.",
                    #                 # "Если в данных видишь число, считай, что это тенге.",
                    #                 "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
                    #                 "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
                    # ],
                    instructions=get_agent_instructions(),
                    name=get_agent_name(),
                    role=get_agent_role(),
                    db=get_agent_db(),
                    add_datetime_to_context=True,
                    add_history_to_context=True,
                    num_history_runs=3,
                    markdown=True
                    )
        return res
    except Exception as e:
        flush_log_except(f"except get_agent(): {e}")


def get_agent_name() -> str:  # TOTHINK
    # origin - 09.05.2026, last edit - 10.05.2026
    res = ""
    try:
        res = "Галым"  # TOTHINK
    except Exception as e:
        flush_log_except(f"except get_agent_name(): {e}")
    return res


def get_agent_role() -> str:  # TOTHINK
    # origin - 09.05.2026, last edit - 10.05.2026
    res = ""
    try:
        res = "менеджер продаж металлопроката"  # TOTHINK
    except Exception as e:
        flush_log_except(f"except get_agent_role(): {e}")
    return res


def get_agent_db() -> SqliteDb:
    # origin - 09.05.2026, last edit - 10.05.2026
    res = SqliteDb()
    try:
        res = SqliteDb(db_file="storage/agents.db")
    except Exception as e:
        flush_log_except(f"except get_db(): {e}")
    return res


def get_price_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 10.05.2026
    res = []
    try:
        pass
    except Exception as e:
        flush_log_except(f"except get_price_list(): {e}")
    return res


def get_rest_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 10.05.2026
    res = []
    try:
        pass
    except Exception as e:
        flush_log_except(f"except get_rest_list(): {e}")
    return res


def get_knowledge_list() -> []:  # TODO
    # origin - 08.05.2026, last edit - 10.05.2026
    res = []
    try:
        pass
    except Exception as e:
        flush_log_except(f"except get_knowledge_list(): {e}")
    return res


def get_product_price(product_name: str) -> str:
    # origin - 07.05.2026, last edit - 10.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        res = get_product_price_exact(product_name)

        # если не нашли по точному наим-ю товара, ищем по нечеткому поиску
        if not res:
            res = get_product_price_fuzz(product_name)

        # # если не нашли по нечеткому поиску, ищем по синониму # this is not work
        # if not res:
        #     res = get_product_price_by_synonym(product_name)

        if not res:
            res = "Товар " + product_name + " не найден в прайс-листе."
    except Exception as e:
        flush_log_except(f"except get_product_price(str): {product_name} {e}")
    return res


def get_product_price_exact(product_name: str) -> str:
    # origin - 09.05.2026, last edit - 11.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        with open('Price/price.csv', mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                if row['Name'].lower() == product_name.lower():
                    res = f"Цена товара '{row['Name']
                                          }' составляет {row['Price']}."
                    break
    except Exception as e:
        flush_log_except(f"except get_product_price_exact(str): {product_name} {e}")
    return res


# нечеткий поиск (fuzzing)
def get_product_price_fuzz(product_name: str) -> str:
    # origin - 09.05.2026, last edit - 10.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        # score_cutoff=70 означает, что сходство должно быть не ниже 70%
        data = list(csv.DictReader('Price/price.csv'))
        names = [row['Name'] for row in data]
        best_match, score = process.extractOne(
            product_name, names, score_cutoff=70) or (None, 0)

        if best_match:
            # Находим цену для найденного похожего товара
            price = next(row['Price']
                         for row in data if row['Name'] == best_match)
            res = f"Точное совпадение не найдено. Возможно, вы имели в виду '{
                best_match}'? Его цена — {price}."
    except Exception as e:
        flush_log(f"get_product_price_fuzz(str): {product_name} {e}")
    return res


# def get_product_price_by_synonym(product_name: str) -> str:  # TODO
#     # origin - 10.05.2026, last edit - 11.05.2026
#     res = "?"
#     try:
#         if not product_name:
#             return res

#         with open('Price/price.csv', mode='r', encoding='utf-8-sig') as f:
#             reader = csv.DictReader(f, delimiter=';')
#             for row in reader:
#                 str_product_name = row['Name']
#                 str_synonym = row['Synonym'].strip()
#                 if not str_synonym:
#                     synonym_list = row['Synonym'].split(":")
#                     print(f"product_name={str_product_name}, synonym_list={synonym_list}.")
#                     for synonym in synonym_list:
#                         if synonym.lower() == product_name.lower():
#                             res = f"Цена товара '{product_name}' составляет {row['Price']}."
#                 # break
#     except Exception as e:
#         flush_log_except(f"except get_product_price_by_synonym(str): {product_name} {e}")
#     return res


# def is_project() -> bool:  # TODO
#     # origin - 09.05.2026, last edit - 10.05.2026
#     res = False
#     try:
#         if os.path.isfile(".project"):
#             res = True
#     except Exception as e:
#         flush_log_except(f"except is_project(): {e}")
#     return res


def flush_log(str) -> None:
    # origin - 08.05.2026, last edit - 08.05.2026
    try:
        with open('log_chat.txt', 'a', encoding='utf-8') as f:
            f.write(str + '\n')
    except Exception as e:
        print(f"except add_write_log(): {e}")


def flush_log_except(str) -> None:
    # origin - 10.05.2026, last edit - 10.05.2026
    try:
        print(str)  # also output to console if except
        with open('log_chat.txt', 'a', encoding='utf-8') as f:
            f.write(str + '\n')
    except Exception as e:
        print(f"except add_write_log(): {str} {e}")


# main
if __name__ == "__main__":
    main()
