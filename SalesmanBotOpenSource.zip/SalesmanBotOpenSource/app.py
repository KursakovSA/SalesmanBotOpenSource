# origin - 07.05.2026, last edit - 29.05.2026
from agno.agent import Agent
from agno.models.ollama import Ollama
import time
import dal
import log
import chat
import price

# global vars
price_list = []
rest_list = []


def main():
    # origin - 07.05.2026, last edit - 28.05.2026
    try:
        get_init()
        log.flush_chat(" ")
        log.flush_chat(" Start agent.")
        print("Start agent.")
        while True:
            get_chat(get_agent())
            user_input = input("End agent (empty input) ?")

            if not user_input:
                break

        print("End agent.")
        log.flush_chat(" End agent.")
        log.flush_chat(" ")
    except Exception as e:
        log.flush_except(f"except app.main(): {e}")


def get_init() -> None:
    # origin - 07.05.2026, last edit - 28.05.2026
    try:
        dal.get_init_work_database()
        price.get_price_list()  # TOTHINK
        get_rest_list()  # TOTHINK
    except Exception as e:
        log.flush_except(f"except app.get_init(): {e}")


def get_chat(agent) -> None:
    # origin - 07.05.2026, last edit - 28.05.2026
    try:
        currChat = chat.initchat1()
        log.flush_chat(" ")
        print("chatId "+currChat.chatId+". Start chat.")
        log.flush_chat("chatId "+currChat.chatId+". Start chat.")
        while True:
            user_input = input("chatId "+currChat.chatId+". Вопрос: ")
            log.flush_chat("chatId "+currChat.chatId+". Вопрос: "+user_input)

            if not user_input:
                break

            start_time = time.perf_counter()
            print("Ищу ответ...")
            response = agent.run(user_input)

            # print("Нашел ответ.")
            response_output = f"chatId {currChat.chatId} Ответ: {response.content}"
            end_time = time.perf_counter()
            time_output = f" ⏱ Заняло: {end_time - start_time:.2f} сек.)"
            print(response_output+", "+time_output)
            log.flush_chat(response_output+", "+time_output)

        print("chatId "+currChat.chatId+". End chat.")
        log.flush_chat("chatId "+currChat.chatId+". End chat.")
        log.flush_chat(" ")
    except Exception as e:
        log.flush_except(f"except app.get_chat(agent): {e}")


def get_model() -> Ollama:
    # origin - 07.05.2026, last edit - 28.05.2026
    res = Ollama()
    # currModel = model.init1()
    try:
        # res = Ollama(id="llama3.1", options=get_model_options())
        # res = Ollama(id="ministral-3:3b", options=get_model_options())
        res = Ollama(id="ministral-3:3b", options=chat.get_model_options())
        # res = Ollama(id="llama3.1", options=get_model_options(), cache_response=True)
        # models qwenxxxx not work right !!!!!
    except Exception as e:
        log.flush_except(f"except app.get_model(): {e}")
    return res


# def get_model_options() -> dict:
#     # origin - 09.05.2026, last edit - 28.05.2026
#     res = {}
#     try:
#         res = {
#             "num_ctx": 4096, "temperature": 0.1, "seed": 42}
#     except Exception as e:
#         log.flush_except(f"except app.get_model_options(): {e}")
#     return res


# def get_agent_description() -> str:
#     # origin - 07.05.2026, last edit - 10.05.2026
#     res = ""
#     try:
#         res = "Ты менеджер продаж металлопроката. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев"
#     except Exception as e:
#         log.flush_except(f"except app.get_agent_description(): {e}")
#     return res


# def get_agent_tools() -> []:
#     # origin - 07.05.2026, last edit - 28.05.2026
#     res = []
#     try:
#         # res = [get_product_price, ReasoningTools()]
#         res = [get_product_price]
#     except Exception as e:
#         log.flush_except(f"except app.get_agent_tools(): {e}")
#     return res


# def get_agent_instructions() -> []:  # TOTHINK
#     # origin - 07.05.2026, last edit - 28.05.2026
#     res = []
#     try:
#         res = [
#             "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров.",
#             "Вы — помощник по расчету стоимости арматуры.",
#             "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
#             "Никогда не используй слово 'рубли' или символ '₽'.",
#             "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
#             "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
#         ],
#     except Exception as e:
#         log.flush_except(f"except app.get_agent_instructions(): {e}")
#     return res


def get_agent() -> Agent:
    # origin - 07.05.2026, last edit - 28.05.2026
    res = Agent
    currAgentParams = chat.initagentparams1()
    try:
        res = Agent(model=get_model(),
                    description=currAgentParams.description,
                    tools=currAgentParams.tools,
                    instructions=currAgentParams.instructions,
                    name=currAgentParams.name,
                    role=currAgentParams.role,
                    add_datetime_to_context=True,
                    add_history_to_context=False,
                    num_history_runs=3,
                    markdown=True
                    )
        return res
        # res = Agent(model=get_model(),
        #             description=get_agent_description(),
        #             tools=get_agent_tools(),
        #             instructions=get_agent_instructions(),
        #             name=get_agent_name(),
        #             role=get_agent_role(),
        #             add_datetime_to_context=True,
        #             add_history_to_context=False,
        #             num_history_runs=3,
        #             markdown=True
        #             )
        # return res
    except Exception as e:
        log.flush_except(f"except app.get_agent(): {e}")


# def get_agent_name() -> str:  # TOTHINK
#     # origin - 09.05.2026, last edit - 28.05.2026
#     res = ""
#     try:
#         res = "Галым"  # TOTHINK
#     except Exception as e:
#         log.flush_except(f"except app.get_agent_name(): {e}")
#     return res


# def get_agent_role() -> str:  # TOTHINK
#     # origin - 09.05.2026, last edit - 28.05.2026
#     res = ""
#     try:
#         res = "менеджер продаж металлопроката"  # TOTHINK
#     except Exception as e:
#         log.flush_except(f"except app.get_agent_role(): {e}")
#     return res


# def get_price_list() -> []:  # TODO
#     # origin - 07.05.2026, last edit - 27.05.2026
#     res = []
#     try:
#         pass
#     except Exception as e:
#         log.flush_except(f"except app.get_price_list(): {e}")
#     return res


def get_rest_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 27.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log.flush_except(f"except app.get_rest_list(): {e}")
    return res


# def get_product_price(product_name: str) -> str:
#     # origin - 07.05.2026, last edit - 27.05.2026
#     res = "?"
#     try:
#         if not product_name:
#             return res

#         res = get_product_price_exact(product_name)

#         # если не нашли по точному наим-ю товара, ищем по нечеткому поиску
#         if not res:
#             res = get_product_price_fuzz(product_name)

#         if not res:
#             res = "Товар " + product_name + " не найден в прайс-листе."
#     except Exception as e:
#         log.flush_except(f"except app.get_product_price(str): {product_name} {e}")
#     return res


# def get_product_price_exact(product_name: str) -> str:
#     # origin - 09.05.2026, last edit - 27.05.2026
#     res = "?"
#     try:
#         if not product_name:
#             return res

#         with open('price_data/price.csv', mode='r', encoding='utf-8-sig') as f:
#             reader = csv.DictReader(f, delimiter=';')
#             for row in reader:
#                 if row['Name'].lower() == product_name.lower():
#                     res = f"Цена товара '{row['Name']
#                                           }' составляет {row['Price']}."
#                     break
#     except Exception as e:
#         log.flush_except(f"except app.get_product_price_exact(str): {product_name} {e}")
#     return res


# # нечеткий поиск (fuzzing)
# def get_product_price_fuzz(product_name: str) -> str:
#     # origin - 09.05.2026, last edit - 27.05.2026
#     res = "?"
#     try:
#         if not product_name:
#             return res

#         # score_cutoff=70 означает, что сходство должно быть не ниже 70%
#         data = list(csv.DictReader('price_data/price.csv'))
#         names = [row['Name'] for row in data]
#         best_match, score = process.extractOne(
#             product_name, names, score_cutoff=70) or (None, 0)

#         if best_match:
#             # Находим цену для найденного похожего товара
#             price = next(row['Price']
#                          for row in data if row['Name'] == best_match)
#             res = f"Точное совпадение не найдено. Возможно, вы имели в виду '{
#                 best_match}'? Его цена — {price}."
#     except Exception as e:
#         log.flush_except(f"except app.get_product_price_fuzz(str): {product_name} {e}")
#     return res


# main
if __name__ == "__main__":
    main()
