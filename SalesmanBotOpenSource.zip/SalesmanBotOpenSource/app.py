from agno.agent import Agent
from agno.models.ollama import Ollama
from agno.db.sqlite import SqliteDb
import time
import csv


def get_product_price(product_name: str) -> str:
    """
    Ищет цену товара по его наименованию в файле Price/price.csv.
    :param product_name: Наименование товара.
    """
    try:
        with open('Price/price.csv', mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                # Сравнение без учета регистра
                if row['Name'].lower() == product_name.lower():
                    return f"Цена товара '{row['Name']}' составляет {row['Price']}."
        return "Товар не найден в прайс-листе."
    except FileNotFoundError:
        return "Ошибка: Файл Price/price.csv не найден."

# test get_product_price
# print(get_product_price("Арматура 20"))
# print(get_product_price("Арматура20"))
# print(get_product_price("Молоко"))


agent = Agent(
    model=Ollama(id="llama3.1", options={
                 "num_ctx": 4096, "temperature": 0.1, "seed": 42}),
    # model=Ollama(id="qwen2.5:3b", options={"num_ctx": 4096, "temperature": 0.1, "seed": 42}),
    description="Ты Гылым, менеджер продаж металлопроката, который расспрашивает клиента покупателя о том, что ему надо. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев",
    tools=[get_product_price],
    # instructions=["Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров."],
    instructions=[
        "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров."
        "Вы — помощник по расчету стоимости арматуры.",
        "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
        "Никогда не используй слово 'рубли' или символ '₽'.",
        "Если в данных видишь число, считай, что это тенге."
        "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
        "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
    ],
    # instructions=["Отвечай кратко и по существу","Всегда используй аннотации типов", "Добавляй docstrings к функциям"],
    # instructions=[
    # "Если пользователь спрашивает цену, всегда используй инструмент get_product_price.",
    # "Если точного совпадения нет, попробуй найти похожие названия."
    # ],
    db=SqliteDb(db_file="storage/agents.db"),
    add_history_to_context=True,
    num_history_runs=3,
    markdown=False
)

while True:
    user_input = input("\nВы: ").strip()

    if not user_input:
        continue

    start_time = time.perf_counter()
    response = agent.run(user_input)

    print(f"Бот: {response.content}")
    end_time = time.perf_counter()

    print(f"\n⏱ Заняло: {end_time - start_time:.2f} сек.")
