# origin - 07.05.2026, last edit - 08.05.2026
from agno.agent import Agent
from agno.models.ollama import Ollama
from agno.db.sqlite import SqliteDb
import time
import csv

# global vars
log_buffer_chat = []
log_buffer_except = []
price_list = []
rest_list = []


def main():
    # origin - 07.05.2026, last edit - 07.05.2026
    get_init()
    get_test()
    get_chat(get_agent())


def get_init() -> None:
    # origin - 07.05.2026, last edit - 07.05.2026
    try:
        get_price_list()
        get_rest_list()
    except Exception as e:
        log_buffer_except.append(f"except get_init(): {e}")


def get_chat(agent) -> None:
    # origin - 07.05.2026, last edit - 08.05.2026
    try:
        while True:
            user_input = input("\nВы: ").strip()
            log_buffer_chat.append("\nВы: "+user_input)

            if not user_input:
                # continue
                break

            start_time = time.perf_counter()
            response = agent.run(user_input)
            response_output = f"Бот: {response.content}"

            # print(f"Бот: {response.content}")
            # print(response_output)
            end_time = time.perf_counter()

            time_output = f" ⏱ Заняло: {end_time - start_time:.2f} сек.)"
            # print(f"\n⏱ Заняло: {end_time - start_time:.2f} сек.")
            print(response_output+", "+time_output)
            log_buffer_chat.append(response_output+", "+time_output)

        with open('log_chat.txt', 'a', encoding='utf-8') as f:  # ?as res ?
            f.write('\n'.join(log_buffer_chat) + '\n')
            f.write('\n'.join(log_buffer_except) + '\n')
    except Exception as e:
        log_buffer_except.append(f"except get_chat(): {e}")


def get_test() -> None:
    # origin - 07.05.2026, last edit - 07.05.2026
    try:
        # print(get_agent().id)
       # print(get_model())
        # print(get_price_list())
        # print(get_rest_list())

        print(get_product_price("Арматура 20"))
        print(get_product_price("Арматура20"))
        print(get_product_price("Молоко"))
    except Exception as e:
        log_buffer_except.append(f"except get_test(): {e}")


def get_model() -> Ollama:
    # origin - 07.05.2026, last edit - 08.05.2026
    try:
        res = Ollama()
        res = Ollama(id="llama3.1", options={
            "num_ctx": 4096, "temperature": 0.1, "seed": 42})
        # res = Ollama(id="qwen2.5:3b", options={
        #     "num_ctx": 4096, "temperature": 0.1, "seed": 42})
        # res = Ollama(id="qwen2.5:1.5b", options={
        #     "num_ctx": 4096, "temperature": 0.1, "seed": 42})
        # res=Ollama(id="qwen2.5:0.5b", options={"num_ctx": 4096, "temperature": 0.1, "seed": 42})
    except Exception as e:
        log_buffer_except.append(f"except get_model(): {e}")
    return res


def get_agent_description() -> []:  # TODO
    # origin - 07.05.2026, last edit - 08.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except get_agent_description(): {e}")
    return res


def get_agent_tool() -> []:  # TODO
    # origin - 07.05.2026, last edit - 08.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except get_agent_tool(): {e}")
    return res


def get_agent_instruction() -> []:  # TODO
    # origin - 07.05.2026, last edit - 08.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except get_agent_instruction(): {e}")
    return res


def get_agent() -> Agent:
    # origin - 07.05.2026, last edit - 08.05.2026
    try:
        res = Agent(model=get_model(),
                    # res=Ollama(id="llama3.1", options={
                    #              "num_ctx": 4096, "temperature": 0.1, "seed": 42}),
                    # res=Ollama(id="qwen2.5:3b", options={"num_ctx": 4096, "temperature": 0.1, "seed": 42}),
                    # res=Ollama(id="qwen2.5:1.5b", options={"num_ctx": 4096, "temperature": 0.1, "seed": 42}),
                    # res=Ollama(id="qwen2.5:0.5b", options={"num_ctx": 4096, "temperature": 0.1, "seed": 42}),
                    description="Ты Галым, менеджер продаж металлопроката, который расспрашивает клиента покупателя о том, что ему надо. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев",
                    tools=[get_product_price],
                    instructions=[
            "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров."
            "Вы — помощник по расчету стоимости арматуры.",
            "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
            "Никогда не используй слово 'рубли' или символ '₽'.",
            "Если в данных видишь число, считай, что это тенге."
            "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
            "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь."
        ],
            # instructions=["Отвечай кратко и по существу","Всегда используй аннотации типов", "Добавляй docstrings к функциям"],
            # instructions=[
            # "Если пользователь спрашивает цену, всегда используй инструмент get_product_price.",
            # "Если точного совпадения нет, попробуй найти похожие названия."
            # ],
            db=SqliteDb(db_file="storage/agents.db"),
            add_history_to_context=True,
            num_history_runs=3,
            markdown=False
        )
        return res
    except Exception as e:
        log_buffer_except.append(f"except get_agent(): {e}")


def add_log(str) -> None:  # TODO
    # origin - 07.05.2026, last edit - 07.05.2026
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except add_log(): {e}")


def add_log2(str) -> None:  # TODO
    # origin - 07.05.2026, last edit - 07.05.2026
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except add_log2(): {e}")


def get_price_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 07.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except get_price_list(): {e}")
    return res


def get_rest_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 07.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except get_rest_list(): {e}")
    return res


def get_knowledge_list() -> []:  # TODO
    # origin - 08.05.2026, last edit - 07.08.2026
    res = []
    try:
        pass
    except Exception as e:
        log_buffer_except.append(f"except get_knowledge_list(): {e}")
    return res


def get_product_price(product_name: str) -> str:
    # origin - 07.05.2026, last edit - 08.05.2026
    res = ""
    try:
        with open('Price/price.csv', mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                if row['Name'].lower() == product_name.lower():
                    res = f"Цена товара '{row['Name']
                                          }' составляет {row['Price']}."

        if not res:
            res = "Товар " + product_name + " не найден в прайс-листе."

    except Exception as e:
        log_buffer_except.append(f"get_product_price(str): {e}")
    return res


# main
if __name__ == "__main__":
    main()
