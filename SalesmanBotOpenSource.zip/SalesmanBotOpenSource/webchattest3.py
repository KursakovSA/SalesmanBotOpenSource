# Вместо import requests используем curl_cffi
from curl_cffi import requests

url = "https://point1.kazprom.com:8000/chat"
# Передаем "text", так как в вашей Pydantic-модели прописано text: str
payload = {"text": "Сколько стоит Арматура 20 ?"}

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
}

try:
    # Передаем параметр impersonate="chrome"
    response = requests.post(
        url,
        json=payload,
        headers=headers,
        timeout=(15, 300),
        verify=False,
        impersonate="edge"
    )
    print(response.text)
except Exception as e:
    print(f"Ошибка при запросе: {e}")
