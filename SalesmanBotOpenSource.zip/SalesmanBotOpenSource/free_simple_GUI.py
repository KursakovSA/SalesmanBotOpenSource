# origin - 30.05.2026, last edit - 30.05.2026
import FreeSimpleGUI as sg
import sqlite3


def get():
    # origin - 30.05.2026, last edit - 30.05.2026
    try:
        # Получение данных
        conn = sqlite3.connect("db/MyWorkBase1.sqlite3")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM role")
        data = cursor.fetchall()
        headings = ["Id", "Parent", "Date1", "Date2", "Code", "Description", "More"]

        # Проектирование интерфейса

        menu_definition = [
            ['&Файл', ['&Открыть', '&Сохранить', '---', 'Вы&ход']],  # '---' создает линию-разделитель
            ['&Правка', ['Копировать', 'Вставить']],
            ['&Справка', ['О программе']]
        ]

        # menu_layout = [[sg.Menu(menu_definition, tearoff=False, key='-MENU-')]]

        layout = [
            [sg.Table(values=data, headings=headings, display_row_numbers=False,
                      auto_size_columns=True, key="-TABLE-")],
            [sg.Button("Закрыть")],
            [sg.Menu(menu_definition, tearoff=False, key='-MENU-')]
        ]

        # Запуск окна
        window = sg.Window("База данных", layout)
        while True:
            event, values = window.read()
            if event in (sg.WIN_CLOSED, "Закрыть"):
                break

        window.close()
        conn.close()

    except Exception as e:
        print(f"except free_simple_GUI.get(): {e}")


if __name__ == "__main__":
    get()
