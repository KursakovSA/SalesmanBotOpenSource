# origin - 01.06.2026, last edit - 24.06.2026
import requests
from fastapi import FastAPI, Request, Response
import chat

objFastAPI = FastAPI()

# Настройки Meta и Agno
META_TOKEN = "ВАШ_PERMANENT_ACCESS_TOKEN"
PHONE_NUMBER_ID = "ВАШ_PHONE_NUMBER_ID"
VERIFY_TOKEN = "ПРИДУМАННЫЙ_ВАМИ_ТОКЕН_ДЛЯ_META"

# Инициализация агента Agno с локальной Ollama
agent = chat.get_agent()


@objFastAPI.get("/webhook")
def verify_webhook(request: Request):
    """Метод для верификации webhook сервером Meta"""
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return Response(content=params.get("hub.challenge"), media_type="text/plain")
    return Response(content="Forbidden", status_code=403)


@objFastAPI.post("/webhook")
async def handle_whatsapp_message(request: Request):
    """Метод для приема и обработки сообщений"""
    data = await request.json()
    try:
        # Извлечение текста сообщения и номера отправителя
        entry = data["entry"][0]["changes"][0]["value"]
        if "messages" in entry:
            message = entry["messages"][0]
            from_number = message["from"]
            user_text = message["text"]["body"]

            # Генерация ответа через Agno + Ollama
            response = agent.run(user_text)
            ai_reply = response.content

            # Отправка ответа в WhatsApp через Meta API
            send_whatsapp_message(from_number, ai_reply)
    except Exception as e:
        print(f"Ошибка обработки: {e}")

    return {"status": "ok"}


def send_whatsapp_message(to_number, text):
    url = f"https://facebook.com{PHONE_NUMBER_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    payload = {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "text",
        "text": {"body": text}
    }
    requests.post(url, json=payload, headers=headers)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("whatsappchat3:objFastAPI", host="0.0.0.0", port=8000, reload=True)
