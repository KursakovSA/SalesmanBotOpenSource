from datetime import datetime


def flush_chat(str) -> None:
    # origin - 27.05.2026, last edit - 27.05.2026
    str = str.strip()
    if str:
        str = get_curr_datetime()+str
    try:
        with open('log_chat.txt', 'a', encoding='utf-8') as f:
            f.write(str + '\n')
    except Exception as e:
        print(f"except log.flush_chat(str): {e}")


def flush_test(str) -> None:
    # origin - 27.05.2026, last edit - 27.05.2026
    str = str.strip()
    if str:
        str = get_curr_datetime()+str
    try:
        print(str)  # also output to console if test
        with open('log_sys.txt', 'a', encoding='utf-8') as f:
            f.write(str + '\n')
    except Exception as e:
        print(f"except log.flush_test(str): {str} {e}")


def flush_sys(str) -> None:
    # origin - 27.05.2026, last edit - 27.05.2026
    str = str.strip()
    if str:
        str = get_curr_datetime()+str
    try:
        with open('log_sys.txt', 'a', encoding='utf-8') as f:
            f.write(str + '\n')
    except Exception as e:
        print(f"except log.flush_sys(str): {str} {e}")


def flush_except(str) -> None:
    # origin - 27.05.2026, last edit - 27.05.2026
    str = str.strip()
    if str:
        str = get_curr_datetime()+str
    try:
        print(str)  # also output to console if except
        with open('log_sys.txt', 'a', encoding='utf-8') as f:
            f.write(str + '\n')
    except Exception as e:
        print(f"except log.flush_except(str): {str} {e}")


def get_curr_datetime() -> str:
    # origin - 10.05.2026, last edit - 27.05.2026
    res = ""
    try:
        res = f"[{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}]"
    except Exception as e:
        flush_except(f"except log.get_curr_datetime(): {e}")
    return res


@staticmethod
def test():
    # origin - 27.05.2026, last edit - 27.05.2026
    try:
        pass
    except Exception as e:
        flush_except(f"except log.test(): {e}")
