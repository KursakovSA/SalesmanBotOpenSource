# origin - 07.05.2026, last edit - 18.07.2026
import dal
import log
from agno.models.ollama import Ollama
from agno.agent import Agent
import random
import price
import time
# import rest

# global vars
price_list = []
rest_list = []


def main():
    # origin - 07.05.2026, last edit - 18.07.2026
    try:
        dal.get_init_work_database()
        # price.get_price_list()  # TOTHINK
        # rest.get_rest_list()  # TOTHINK

        log.flush_chat(" ")
        log.flush_chat(" Start agent.")
        print("Start agent.")
        while True:
            # chat.get_chat(chat.get_agent())
            get_chat(get_agent())
            user_input = input("End agent (empty input) ?")

            if not user_input:
                break

        print("End agent.")
        log.flush_chat(" End agent.")
        log.flush_chat(" ")
    except Exception as e:
        log.flush_except(f"except _start.main(): {e}")


def get_chat(agent) -> None:
    # origin - 18.07.2026, last edit - 18.07.2026
    try:
        currChat = initchat()

        log.flush_chat(" ")
        log.flush_chat("chatId "+currChat.get("chatId")+". Start chat.")

        while True:
            user_input = input("chatId "+currChat.get("chatId")+". Вопрос: ")
            log.flush_chat("chatId "+currChat.get("chatId")+". Вопрос: "+user_input)

            if not user_input:
                break

            start_time = time.perf_counter()
            print("Ищу ответ...")
            response = agent.run(user_input)
            response_output = f"chatId {currChat.get("chatId")} Ответ: {response.content}"
            end_time = time.perf_counter()
            time_output = f" ⏱ Заняло: {end_time - start_time:.2f} сек.)"
            log.flush_chat(response_output+", "+time_output)

        log.flush_chat("chatId "+currChat.get("chatId")+". End chat.")
        log.flush_chat(" ")
    except Exception as e:
        log.flush_except(f"except chat.get_chat(agent): {e}")


def get_agentparams() -> dict:
    # origin - 18.07.2026, last edit - 18.07.2026
    res = {}
    try:
        res["name"] = "Галым"  # TOTHINK from db
        res["description"] = "Ты менеджер продаж металлопроката. Клиент может покупать металлопрокат, а также дополнительно заказывать его обработку, или постройку из него простых сооружений - ангаров, складов, сараев"
        res["role"] = "менеджер продаж металлопроката"  # TOTHINK from db
        res["instructions"] = [
            "Используй инструмент поиска цен get_product_price для ответа на вопросы о стоимости товаров.",
            "Вы — помощник по расчету стоимости арматуры.",
            "Все цены в ответах ОБЯЗАТЕЛЬНО должны указываться в тенге.",
            "Никогда не используй слово 'рубли' или символ '₽'.",
            "Если пользователь спрашивает цену товара, ВСЕГДА используй инструмент get_product_price.",
            "Никогда не придумывай цену сам, даже если тебе кажется, что ты её знаешь.",
            "Твоя задача — извлечь название товара из запроса пользователя для поиска по прайс-листу.",
            "ПРАВИЛО: Извлекай название ТОЛЬКО в том виде, в каком оно написано в вопросе.",
            "ЗАПРЕЩЕНО добавлять слова 'диаметр', 'размер', 'тип' или менять падежи, если их нет в исходном тексте.",
            "Пример 1: 'Сколько стоит Арматура 20' -> 'Арматура 20' (НЕ 'Арматура диаметром 20')",
            "Пример 2: 'Цена на Трубу 50' -> 'Труба 50'"
        ]  # TOTHINK from db
        # res.tools = [price.get_product_price]  # TOTHINK from db
        res["tools"] = [get_product_price]
    except Exception as e:
        log.flush_except(f"except _start.get_agentparams(): {e}")
    return res


def get_agent() -> Agent:
    # origin - 18.07.2026, last edit - 18.07.2026
    res = Agent
    agentparams = get_agentparams()
    try:
        res = Agent(model=get_model(),
                    description=agentparams.get("description"),
                    tools=agentparams.get("tools"),
                    instructions=agentparams.get("instructions"),
                    name=agentparams.get("name"),
                    role=agentparams.get("role"),
                    add_datetime_to_context=True,
                    add_history_to_context=False,
                    num_history_runs=3,
                    markdown=False
                    )
        return res
    except Exception as e:
        log.flush_except(f"except _start.get_agent(): {e}")


def get_model() -> Ollama:
    # origin - 18.07.2026, last edit - 18.07.2026
    res = Ollama()
    try:
        res = Ollama(id="ministral-3:3b",
                     options={"num_ctx": 2048, "temperature": 0.1, "seed": 42})
        # models qwenxxxx not work right !!!!!
    except Exception as e:
        log.flush_except(f"except _start.get_model(): {e}")
    return res


def initchat() -> dict:
    # origin - 18.07.2026, last edit - 18.07.2026
    res = {}
    try:
        res["chatId"] = str(random.randint(1000, 9999))
        res["date1"] = log.get_curr_datetime()
    except Exception as e:
        log.flush_except(f"except _start.initchat(): {e}")
    return res


def get_product_price(product_name: str) -> str:
    # origin - 27.06.2026, last edit - 28.06.2026
    res = ""
    try:
        res = price.get(product_name)
    except Exception as e:
        log.flush_except(f"except _start.get_product_price(str): {product_name} {e}")
    return res


# def get_init() -> None:
#     # origin - 07.05.2026, last edit - 28.06.2026
#     try:
#         dal.get_init_work_database()
#         # price.get_price_list()  # TOTHINK
#         # rest.get_rest_list()  # TOTHINK
#     except Exception as e:
#         log.flush_except(f"except _start.get_init(): {e}")


if __name__ == "__main__":
    main()
