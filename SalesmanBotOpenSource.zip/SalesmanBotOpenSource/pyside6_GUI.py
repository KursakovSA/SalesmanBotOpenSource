import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QTabWidget, 
                             QTableWidget, QTableWidgetItem, QVBoxLayout, 
                             QWidget)
from PySide6.QtGui import QAction

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Приложение на PySide6")
        self.resize(600, 400)

        # 1. Создание главного меню
        self.setup_menu()

        # 2. Создание виджета вкладок (Tabs)
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # 3. Создание содержимого вкладок
        self.tab1 = QWidget()
        self.tab2 = QWidget()
        
        self.tabs.addTab(self.tab1, "Вкладка с таблицей")
        self.tabs.addTab(self.tab2, "Пустая вкладка")

        # 4. Наполнение первой вкладки таблицей
        self.setup_table_tab()

    def setup_menu(self):
        """Создание верхнего меню"""
        menu_bar = self.menuBar()
        
        # Меню Файл
        file_menu = menu_bar.addMenu("Файл")
        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Меню Помощь
        help_menu = menu_bar.addMenu("Помощь")
        about_action = QAction("О программе", self)
        help_menu.addAction(about_action)

    def setup_table_tab(self):
        """Создание таблицы с видимыми границами"""
        # Вертикальный лейаут для размещения таблицы на вкладке
        layout = QVBoxLayout(self.tab1)
        
        # Создаем таблицу 5 строк на 3 колонки
        table = QTableWidget(5, 3)
        
        # Включаем отображение сетки (границ ячеек)
        table.setShowGrid(True)
        
        # Задаем заголовки колонок
        table.setHorizontalHeaderLabels(["Колонка 1", "Колонка 2", "Колонка 3"])

        # Заполняем таблицу демонстрационными данными
        for row in range(5):
            for column in range(3):
                item = QTableWidgetItem(f"Ячейка {row},{column}")
                table.setItem(row, column, item)

        # Добавляем таблицу в лейаут вкладки
        layout.addWidget(table)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.argv = [""] # Сброс аргументов во избежание конфликтов в некоторых IDE
    sys.exit(app.exec())
