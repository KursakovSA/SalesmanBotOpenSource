# origin - 01.06.2026, last edit - 24.06.2026
# import os
from fastapi import FastAPI, Request, Response
# from agno.agent import Agent
# from agno.models.ollama import Ollama
import requests
import chat

objFastAPI = FastAPI()

# Настройка агента Agno с локальной Ollama
agent = chat.get_agent()  # Agent(
# model=Ollama(id="llama3"),
# description="Вы полезный бизнес-ассистент.",
# markdown=False
# )

VERIFY_TOKEN = "my_secure_token_123"  # Токен для проверки Meta
WHATSAPP_TOKEN = "META_PERMANENT_ACCESS_TOKEN"  # Токен владельца бизнеса
PHONE_NUMBER_ID = "META_PHONE_NUMBER_ID"  # ID номера из панели Meta

# 1. Верификация Webhook для Meta


@objFastAPI.get("/webhook")
async def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return Response(content=params.get("hub.challenge"), media_type="text/plain")
    return Response(content="Verification failed", status_code=403)

# 2. Обработка входящих сообщений


@objFastAPI.post("/webhook")
async def receive_message(request: Request):
    data = await request.json()
    try:
        # Извлечение текста и номера отправителя
        entry = data["entry"][0]["changes"][0]["value"]
        if "messages" in entry:
            message = entry["messages"][0]
            from_number = message["from"]
            user_text = message["text"]["body"]

            # Генерация ответа через Agno
            agent_response = agent.get_response(user_text)
            reply_text = agent_response.content

            # Отправка ответа в WhatsApp via Meta API
            url = f"https://facebook.com{PHONE_NUMBER_ID}/messages"
            headers = {"Authorization": f"Bearer {WHATSAPP_TOKEN}",
                       "Content-Type": "application/json"}
            payload = {
                "messaging_product": "whatsapp",
                "to": from_number,
                "type": "text",
                "text": {"body": reply_text}
            }
            requests.post(url, json=payload, headers=headers)
    except Exception as e:
        print(f"Error: {e}")
    return {"status": "ok"}

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)
