import os
import requests
from fastapi import FastAPI, Request, Response, Query
import chat

# Инициализируем агента Agno с моделью Ollama
whatsapp_agent = chat.get_agent()


def get_agent_response(user_message: str) -> str:
    """Функция для передачи сообщения агенту и получения текста ответа"""
    response = whatsapp_agent.run(user_message)
    return response.content


app = FastAPI()

# Настройки Meta API (замените на свои реальные данные из панели Meta)
WHATSAPP_TOKEN = os.getenv("WHATSAPP_TOKEN", "YOUR_META_ACCESS_TOKEN")
PHONE_NUMBER_ID = os.getenv("PHONE_NUMBER_ID", "YOUR_WHATSAPP_PHONE_NUMBER_ID")
VERIFY_TOKEN = os.getenv("VERIFY_TOKEN", "MY_SECRET_VERIFY_TOKEN")


def send_whatsapp_message(to_number: str, text: str):
    """Функция отправки сообщения пользователю через WhatsApp Business API"""
    url = f"facebook.com{PHONE_NUMBER_ID}/messages"
    headers = {
        "Authorization": f"Bearer {WHATSAPP_TOKEN}",
        "Content-Type": "application/json"
    }
    data = {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "text",
        "text": {"body": text}
    }
    response = requests.post(url, json=data, headers=headers)
    return response.json()


@app.get("/webhook")
def verify_webhook(
    mode: str = Query(None, alias="hub.mode"),
    token: str = Query(None, alias="hub.verify_token"),
    challenge: str = Query(None, alias="hub.challenge")
):
    """Верификация Webhook в панели Meta for Developers"""
    if mode == "subscribe" and token == VERIFY_TOKEN:
        return Response(content=challenge, media_type="text/plain")
    return Response(content="Verification failed", status_code=403)


@app.post("/webhook")
async def receive_message(request: Request):
    """Прием сообщений от пользователя и отправка ответа от Agno + Ollama"""
    body = await request.json()

    try:
        # Извлекаем текст сообщения и номер отправителя из структуры Meta JSON
        entry = body["entry"][0]
        changes = entry["changes"][0]
        value = changes["value"]

        if "messages" in value:
            message = value["messages"][0]
            from_number = message["from"]

            if message["type"] == "text":
                user_text = message["text"]["body"]

                # 1. Передаем текст агенту Agno
                ai_response = get_agent_response(user_text)

                # 2. Отправляем ответ обратно в WhatsApp
                send_whatsapp_message(from_number, ai_response)

    except KeyError:
        pass

    return {"status": "success"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
