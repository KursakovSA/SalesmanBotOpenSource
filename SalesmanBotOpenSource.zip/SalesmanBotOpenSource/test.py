# origin - 23.05.2026, last edit - 28.05.2026
import log
import pricelistmap
import pricelistengine
import dto
import chat

# origin - 23.05.2026, last edit - 28.05.2026
try:
    pricelistmap.test()
    pricelistengine.test()
    dto.test()
    chat.testchat()
    chat.testagentparams()

except Exception as e:
    log.flush_except(f"except test.py(): {e}")
