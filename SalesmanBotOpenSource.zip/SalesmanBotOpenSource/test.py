# origin - 23.05.2026, last edit - 27.05.2026
import log
import pricelistmap
import pricelistengine
import dal
import dto
import fmtr

try:
    pricelistmap.test()
    pricelistengine.test()
    dal.test()
    dto.test()
    fmtr.test()

# input()
except Exception as e:
    log.flush_except(f"except test.py(): {e}")
