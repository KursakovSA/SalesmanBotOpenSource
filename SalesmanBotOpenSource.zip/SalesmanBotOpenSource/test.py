# origin - 23.05.2026, last edit - 29.05.2026
import log
import price
import dto
import dal
import chat

# origin - 23.05.2026, last edit - 29.05.2026
try:
    price.test()
    dto.test()
    dal.test()
    chat.test()

except Exception as e:
    log.flush_except(f"except test.py(): {e}")
