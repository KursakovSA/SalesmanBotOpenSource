# origin - 23.05.2026, last edit - 29.05.2026
import log
import price
import dto
import chat

# origin - 23.05.2026, last edit - 29.05.2026
try:
    price.testprice1()
    price.testpricelistmap1()
    dto.testdto1()
    chat.testchat1()
    chat.testagentparams1()

except Exception as e:
    log.flush_except(f"except test.py(): {e}")
