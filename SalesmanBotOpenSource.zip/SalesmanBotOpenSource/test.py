# origin - 23.05.2026, last edit - 25.05.2026
import app
import pricelistmap
import pricelistmanager
import dal

try:
    dal.test()
    pricelistmap.test()
    pricelistmanager.test()

# input()
except Exception as e:
    app.flush_log_except(f"except test.py(): {e}")
