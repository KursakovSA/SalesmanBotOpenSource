# origin - 23.05.2026, last edit - 25.05.2026
import app
import pricelistmap
import pricelistmanager

try:
    pricelistmap.test()
    pricelistmanager.test()

# input()
except Exception as e:
    app.flush_log_except(f"except test(): {e}")
