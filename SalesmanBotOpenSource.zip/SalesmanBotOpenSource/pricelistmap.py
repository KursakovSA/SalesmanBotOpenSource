from dataclasses import dataclass
import app


@dataclass
class PriceListMap:
    # origin - 19.05.2026, last edit - 24.05.2026
    listDelStr = [" "]  # static field
    src0: str = ""
    src1: str = ""
    defect: str = ""
    date1: str = ""
    lastLineTitle: str = ""
    productName: str = ""
    productUnit: str = ""
    priceValue1: str = ""
    priceValue2: str = ""
    productDescription: str = ""
    productGroup: str = ""

    def __init__(self):
        # origin - 19.05.2026, last edit - 23.05.2026
        pass

    # @staticmethod
    def get1(src):
        # origin - 19.05.2026, last edit - 25.05.2026
        res = PriceListMap()
        try:
            res.src0 = src
            res.src1 = src.replace(" ", "")
            items = res.src1.split(",")
            if (len(items) >= 1):
                res.date1 = items[0]
            if (len(items) >= 2):
                res.lastLineTitle = items[1]
            if (len(items) >= 3):
                res.productName = items[2]
            if (len(items) >= 4):
                res.productUnit = items[3]
            if (len(items) >= 5):
                res.priceValue1 = items[4]
            if (len(items) >= 6):
                res.priceValue2 = items[5]
            if (len(items) >= 7):
                res.productDescription = items[6]
            if (len(items) >= 8):
                res.productGroup = items[7]
        except Exception as e:
            app.flush_log_except(f"except get1(): {e}")
        return res

    def __str__(self):
        # origin - 19.05.2026, last edit - 25.05.2026
        res = ""
        try:
            res = res+"src0 "+self.src0
            res = res+", src1 "+self.src1
            res = res+", defect "+self.defect
            res = res+", date1 "+self.date1
            res = res+", lastLineTitle "+self.lastLineTitle
            res = res+", productName "+self.productName
            res = res+", productUnit "+self.productUnit
            res = res+", priceValue1 "+self.priceValue1
            res = res+", priceValue2 "+self.priceValue2
            res = res+", productDescription "+self.productDescription
            res = res+", productGroup "+self.productGroup
            res = "{"+res+"}"
        except Exception as e:
            app.flush_log_except(f"except __str__(): {e}")
        return res


@staticmethod
def test():
    # origin - 19.05.2026, last edit - 25.05.2026
    app.flush_log_test(" ")
    app.flush_log_test("PriceListMap.test()")
    app.flush_log_test("PriceListMap.get1(str).test()")
    for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
        app.flush_log_test("PriceListMap.get1(str), res="+str(PriceListMap.get1(tmp))+", tmp="+tmp)
