import pandas as pd


class PriceList:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = None

    def load(self, sheet_name=0):
        """Загружает данные из Excel файла."""
        try:
            # sheet_name=0 загружает первый лист по умолчанию
            self.data = pd.read_excel(self.file_path, sheet_name=sheet_name)
            print(f"Прайс-лист успешно загружен. Строк: {len(self.data)}")
        except Exception as e:
            print(f"Ошибка при загрузке файла: {e}")

    def get_price(self, item_name, column_name='Цена'):
        """Ищет цену по названию товара."""
        if self.data is None:
            return "Сначала загрузите прайс-лист!"

        # Предполагаем, что названия товаров в колонке 'Наименование'
        result = self.data.loc[self.data['Наименование'] == item_name, column_name]

        return result.values[0] if not result.empty else "Товар не найден"

    def apply_discount(self, percent):
        """Применяет скидку ко всем ценам в прайсе."""
        if self.data is not None:
            self.data['Цена'] = self.data['Цена'] * (1 - percent / 100)


# Пример использования:
price = PriceList('price/price.xlsx')
price.load("прайс")
print(price.get_price('Apple iPhone 15'))
