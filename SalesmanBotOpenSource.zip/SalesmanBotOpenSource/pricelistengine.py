import openpyxl
import log
from thefuzz import process
import csv


class PriceListEngine:
    # origin - 11.05.2026, last edit - 25.05.2026

    def __init__(self):
        # origin - 24.05.2026, last edit - 24.05.2026
        pass

    def load_price(self, sheet_name=None):
        # origin - 11.05.2026, last edit - 27.05.2026
        try:
            # data_only=True позволяет читать значения, а не формулы
            workbook = openpyxl.load_workbook(self.file_path, data_only=True)
            sheet = workbook[sheet_name] if sheet_name else workbook.active

            # Читаем строки, начиная со второй (пропуская заголовок)
            for row in sheet.iter_rows(min_row=2, values_only=True):
                # Пропускаем пустые строки
                if not any(row):
                    continue

                # Пример структуры: Название, Артикул, Цена
                item = {
                    "name": row[0],
                    "sku": row[1],
                    "price": row[2]
                }
                self.data.append(item)

            print(f"Загружено позиций: {len(self.data)}")
        except Exception as e:
            log.flush_except(f"except pricelistengine.load_price(self, str): {e}")

    def get_price_by_sku(self, sku):
        # origin - 11.05.2026, last edit - 27.05.2026
        try:
            for item in self.data:
                if item['sku'] == sku:
                    return item['price']
        except Exception as e:
            log.flush_except(f"except pricelistengine.get_price_by_sku(self, str): {e}")
        return None

    def get_price_by_name(self, name):
        # origin - 11.05.2026, last edit - 27.05.2026
        try:
            for item in self.data:
                if item['name'] == name:
                    return item['price']
        except Exception as e:
            log.flush_except(f"except pricelistengine.get_price_by_name(self, str): {e}")
        return None


# @staticmethod
def get_product_price(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 28.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        res = get_product_price_exact(product_name)

        # если не нашли по точному наим-ю товара, ищем по нечеткому поиску
        if not res:
            res = get_product_price_fuzz(product_name)

        if not res:
            res = "Товар " + product_name + " не найден в прайс-листе."
    except Exception as e:
        log.flush_except(f"except app.get_product_price(str): {product_name} {e}")
    return res


# @staticmethod
def get_product_price_exact(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 28.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        with open('price_data/price.csv', mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                if row['Name'].lower() == product_name.lower():
                    res = f"Цена товара '{row['Name']
                                          }' составляет {row['Price']}."
                    break
    except Exception as e:
        log.flush_except(f"except app.get_product_price_exact(str): {product_name} {e}")
    return res


# @staticmethod
def get_product_price_fuzz(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 28.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        # score_cutoff=70 означает, что сходство должно быть не ниже 70%
        data = list(csv.DictReader('price_data/price.csv'))
        names = [row['Name'] for row in data]
        best_match, score = process.extractOne(
            product_name, names, score_cutoff=70) or (None, 0)

        if best_match:
            # Находим цену для найденного похожего товара
            price = next(row['Price']
                         for row in data if row['Name'] == best_match)
            res = f"Точное совпадение не найдено. Возможно, вы имели в виду '{
                best_match}'? Его цена — {price}."
    except Exception as e:
        log.flush_except(f"except app.get_product_price_fuzz(str): {product_name} {e}")
    return res


@staticmethod
def get_price_list() -> []:  # TODO
    # origin - 28.05.2026, last edit - 28.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log.flush_except(f"except pricelistengine.get_price_list(): {e}")
    return res


@staticmethod
def test():  # TODO
    # origin - 24.05.2026, last edit - 27.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("pricelistengine.test()")
        # plm = PriceListManager("price_data/price.xlsx")
        # plm.load_price()
        # print(f"get_price_by_sku('A100')={plm.get_price_by_sku('A100')}")
        # print(f"get_price_by_name('Арматура 6')={plm.get_price_by_name('Арматура 6')}")
    except Exception as e:
        log.flush_except(f"except pricelistengine.test(): {e}")
