# origin - 25.05.2026, last edit - 25.05.2026
import app
import os
import shutil

TEMPLATE_DB = "DatabaseTemplate.sqlite3"
TARGET_DB = "MyWorkBase1.sqlite3"


def get_init_work_database() -> None:
    # origin - 25.05.2026, last edit - 25.05.2026
    try:
        # Проверяем, существует ли уже рабочая база данных
        if not os.path.exists(TARGET_DB):
            # Проверяем, существует ли шаблон, чтобы избежать ошибок
            if os.path.exists(TEMPLATE_DB):
                shutil.copy2(TEMPLATE_DB, TARGET_DB)
                app.flush_log_sys(f"База данных успешно создана: {TARGET_DB}")
            else:
                app.flush_log_sys(f"Ошибка: Шаблон {TEMPLATE_DB} не найден в корне проекта!")
        else:
            app.flush_log_sys(f"Рабочая база данных {
                              TARGET_DB} уже существует. Копирование не требуется.")
    except Exception as e:
        app.flush_log_except(f"except dal.get_init_work_database(): {e}")


@staticmethod
def test():  # TODO
    # origin - 25.05.2026, last edit - 25.05.2026
    try:
        app.flush_log_test(" ")
        app.flush_log_test("dal.test()")
    except Exception as e:
        app.flush_log_except(f"except dal.test(): {e}")
