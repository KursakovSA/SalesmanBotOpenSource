# origin - 25.05.2026, last edit - 27.05.2026
import log
import os
import shutil
import sqlite3

TEMPLATE_DB = "DatabaseTemplate.sqlite3"
WORK_DB = "MyWorkBase1.sqlite3"


def get_replace_into() -> None:  # TODO
    # origin - 25.05.2026, last edit - 27.05.2026
    try:
        lines_list = ["Первая строка", "Вторая строка", "Третья строка"]
        db_path = os.path.join(os.path.dirname(__file__), WORK_DB)
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
    CREATE TABLE IF NOT EXISTS text_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content TEXT
        )
        """
        )

        # Подготовка данных (метод executemany ожидает кортежи)
        data_to_insert = [(line,) for line in lines_list]
        # Пакетная запись
        cursor.executemany("REPLACE INTO text_data (content) VALUES (?)", data_to_insert)
        conn.commit()
        conn.close()
        log.flush_sys(
            f"Успешно записано {len(lines_list)} строк в {db_path}"
        )
    except Exception as e:
        log.flush_except(f"except dal.get_replace_into(): {e}")


def get_init_work_database() -> None:
    # origin - 25.05.2026, last edit - 27.05.2026
    try:
        if not os.path.exists(WORK_DB):
            if os.path.exists(TEMPLATE_DB):
                shutil.copy2(TEMPLATE_DB, WORK_DB)
                log.flush_sys(f"База данных успешно создана: {WORK_DB}")
            else:
                log.flush_sys(f"Ошибка: Шаблон {TEMPLATE_DB} не найден в корне проекта.")
    except Exception as e:
        log.flush_except(f"except dal.get_init_work_database(): {e}")


@staticmethod
def test():  # TODO
    # origin - 25.05.2026, last edit - 27.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("dal.test()")
    except Exception as e:
        log.flush_except(f"except dal.test(): {e}")
