# origin - 25.05.2026, last edit - 29.05.2026
import log
import shutil
from pathlib import Path


def get_init_work_database() -> None:
    # origin - 25.05.2026, last edit - 28.05.2026
    try:
        project_dir = Path(__file__).resolve().parent
        db_dir = project_dir / "db"
        template_name = "DatabaseTemplate.sqlite3"       # Имя файла-шаблона
        current_name = "MyWorkBase1.sqlite3"     # Имя рабочей базы данных

        template_path = db_dir / template_name
        current_path = db_dir / current_name

        if current_path.exists():
            # print("Рабочая база данных уже существует.")
            return

        if not template_path.exists():
            log.flush_sys(f"Ошибка: Шаблон {template_name} не найден в {db_dir}.")
            return

        shutil.copy2(template_path, current_path)
        log.flush_sys(f"База данных успешно создана: {current_path.name}")
    except Exception as e:
        log.flush_except(f"except dal.get_init_work_database(): {e}")


@staticmethod
def testdal1():  # TODO
    # origin - 25.05.2026, last edit - 29.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("testdal1()")
    except Exception as e:
        log.flush_except(f"except testdal1(): {e}")
