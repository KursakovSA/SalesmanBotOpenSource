# origin - 25.05.2026, last edit - 28.05.2026
import log
# import os
import shutil
# import sqlite3
from pathlib import Path

# FOLDER_DB = "db"
# TEMPLATE_DB = "DatabaseTemplate.sqlite3"
# WORK_DB = "MyWorkBase1.sqlite3"
# TEMPLATE_DB_PATH = FOLDER_DB / TEMPLATE_DB
# WORK_DB_PATH = FOLDER_DB / WORK_DB


# def get_replace_into() -> None:  # TODO
#     # origin - 25.05.2026, last edit - 28.05.2026
#     try:
#         lines_list = ["Первая строка", "Вторая строка", "Третья строка"]
#         db_path = os.path.join(os.path.dirname(__file__), WORK_DB)
#         conn = sqlite3.connect(db_path)
#         cursor = conn.cursor()
#         cursor.execute(
#             """
#     CREATE TABLE IF NOT EXISTS text_data (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         content TEXT
#         )
#         """
#         )

#         # Подготовка данных (метод executemany ожидает кортежи)
#         data_to_insert = [(line,) for line in lines_list]
#         # Пакетная запись
#         cursor.executemany("REPLACE INTO text_data (content) VALUES (?)", data_to_insert)
#         conn.commit()
#         conn.close()
#         log.flush_sys(
#             f"Успешно записано {len(lines_list)} строк в {db_path}"
#         )
#     except Exception as e:
#         log.flush_except(f"except dal.get_replace_into(): {e}")


def get_init_work_database() -> None:
    # origin - 25.05.2026, last edit - 28.05.2026
    try:
        project_dir = Path(__file__).resolve().parent
        db_dir = project_dir / "db"
        template_name = "DatabaseTemplate.sqlite3"       # Имя файла-шаблона
        current_name = "MyWorkBase1.sqlite3"     # Имя рабочей базы данных

        template_path = db_dir / template_name
        current_path = db_dir / current_name

        if current_path.exists():
            # print("Рабочая база данных уже существует.")
            return

        if not template_path.exists():
            log.flush_sys(f"Ошибка: Шаблон {template_name} не найден в {db_dir}.")
            return

        shutil.copy2(template_path, current_path)
        log.flush_sys(f"База данных успешно создана: {current_path.name}")
    except Exception as e:
        log.flush_except(f"except dal.get_init_work_database(): {e}")


# @staticmethod
# def test():  # TODO
#     # origin - 25.05.2026, last edit - 28.05.2026
#     try:
#         log.flush_test(" ")
#         log.flush_test("dal.test()")
#     except Exception as e:
#         log.flush_except(f"except dal.test(): {e}")
