# main.py
from agno.agent import Agent
from agno.models.ollama import Ollama
from agno.app.fastapi import FastAPIApp  # Модуль интеграции AgentOS с FastAPI
from agno.storage.agent.sqlite import SqlAgentStorage  # Самая простая БД для истории

# 1. Создаем агента
agent = Agent(
    id="site-helper",
    model=Ollama(id="llama3.1"),
    # Подключаем встроенную базу данных SQLite для сохранения истории чатов
    storage=SqlAgentStorage(table_name="agent_sessions", db_file="agents.db"),
    add_history_to_messages=True,  # Передавать историю в Ollama для контекста
    markdown=True
)

# 2. Оборачиваем агента в AgentOS через FastAPIApp
# Это автоматически генерирует маршруты /agents/... для фронтенда
app = FastAPIApp(
    agents=[agent],
)

# Получаем стандартное FastAPI приложение для запуска через Uvicorn
backend_api = app.get_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(backend_api, host="0.0.0.0", port=8000)
