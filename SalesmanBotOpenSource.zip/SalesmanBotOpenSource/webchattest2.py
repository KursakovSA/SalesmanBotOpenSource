import urllib3
import requests
from requests.adapters import HTTPAdapter
import ssl

url = "https://point1.kazprom.com:8000/chat"
# Передаем "text", так как в вашей Pydantic-модели прописано text: str
payload = {"text": "Сколько стоит Арматура 20 ?"}

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}


class TLSAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        # Создаем современный контекст для клиента
        context = ssl.create_default_context()

        # Решаем ошибку: полностью отключаем проверку имени хоста
        context.check_hostname = False

        # Решаем ошибку: разрешаем не проверять сертификат (аналог verify=False)
        context.verify_mode = ssl.CERT_NONE

        # Настраиваем только безопасные протоколы без устаревших флагов
        context.minimum_version = ssl.TLSVersion.TLSv1_2

        kwargs['ssl_context'] = context
        return super().init_poolmanager(*args, **kwargs)


session = requests.Session()
session.mount('https://', TLSAdapter())

# Отключаем ворнинги в консоли, так как мы намеренно отключили проверку
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Выполняем ваш запрос (внутри адаптера verify уже отключен, но для requests оставляем False)
try:
    response = session.post(url, json=payload, headers=headers, timeout=(15, 300), verify=False)
    print(response.text)
except Exception as e:
    print(f"Ошибка при запросе: {e}")
