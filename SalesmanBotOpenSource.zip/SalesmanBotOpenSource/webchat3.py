from fastapi.middleware.cors import CORSMiddleware
from agno.agent import Agent
from agno.models.ollama import Ollama
from agno import AgnoApp  # Правильный импорт для создания готового FastAPI приложения

# 1. Создаем вашего агента
web_bot_agent = Agent(
    name="SiteAssistant",
    model=Ollama(id="ministral-3:3b"),
    instructions=[
        "Ты — дружелюбный ИИ-ассистент для поддержки пользователей на нашем сайте.",
        "Отвечай кратко и вежливо.",
    ],
    markdown=True
)

# 2. Оборачиваем в готовое API-приложение фреймворка
app = AgnoApp(
    agents=[web_bot_agent],
    title="Website Chatbot API"
)

# Получаем стандартный FastAPI инстанс для настройки CORS (чтобы сайт мог слать запросы)
fastapi_app = app.get_fastapi_app()

fastapi_app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # В продакшене замените на домен вашего сайта
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

if __name__ == "__main__":
    import uvicorn
    # Запускаем сервер на порту 8000
    uvicorn.run(fastapi_app, host="0.0.0.0", port=8000)


# # from agno.agent import Agent
# # from agno.models.ollama import Ollama
# from agno.agentos.app import AgentOSApp  # Импорт обертки среды выполнения AgentOS
# import chat

# # 1. Инициализируем локального агента с моделью Ollama
# web_bot_agent = chat.get_agent()
# # Agent(
# #     name="SiteAssistant",
# #     model=Ollama(id="ministral-3:3b"),  # Или ваша модель, например qwen2.5
# #     instructions=[
# #         "Ты — дружелюбный ИИ-ассистент для поддержки пользователей на нашем сайте.",
# #         "Отвечай кратко, вежливо и используй Markdown-разметку.",
# #     ],
# #     markdown=True
# # )

# # 2. Оборачиваем агента в приложение AgentOS
# # Это автоматически создает FastAPI сервер со всеми необходимыми эндпоинтами
# app = AgentOSApp(
#     agents=[web_bot_agent],
#     title="Website Chatbot API",
#     # В продакшене укажите конкретный домен вашего сайта во избежание CORS-ошибок
#     allow_origins=["*"]
# )

# if __name__ == "__main__":
#     import uvicorn
#     # Запускаем сервер AgentOS на порту 8000
#     uvicorn.run("webchat3.py:app", host="0.0.0.0", port=8000, reload=True)


# # import os
# from fastapi import FastAPI, HTTPException
# from fastapi.middleware.cors import CORSMiddleware
# from pydantic import BaseModel
# # from agno.agent import Agent
# # from agno.models.ollama import Ollama
# import chat

# # 1. Инициализация FastAPI приложения
# app = FastAPI(title="Agno Chatbot API")

# # Настройка CORS, чтобы ваш сайт мог отправлять запросы к API
# app.add_middleware(
#     CORSMiddleware,
#     # В продакшене замените на домен вашего сайта (напр. ["https://mysite.com"])
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # 2. Настройка ИИ-агента Agno с использованием Ollama
# # Убедитесь, что сервер Ollama запущен локально, а модель (напр., llama3) скачана
# agent = chat.get_agent()
# # Agent(
# #     model=Ollama(id="llama3"),
# #     description="Вы — полезный и вежливый ассистент для нашего веб-сайта.",
# #     markdown=False
# # )

# # 3. Валидация входящих данных от сайта


# class ChatRequest(BaseModel):
#     message: str

# # 4. API Эндпоинт для обработки сообщений


# @app.post("/api/chat")
# async def chat_endpoint(request: ChatRequest):
#     try:
#         # Получение ответа от агента Agno
#         response = await agent.arun(request.message)

#         # Возвращаем текстовый ответ фронтенду
#         return {"response": response.content}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run("webchat3:app", host="0.0.0.0", port=8000)
