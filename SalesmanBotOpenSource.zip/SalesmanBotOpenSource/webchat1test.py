# origin - 02.06.2026, last edit - 03.06.2026
import requests
#import urllib3

# url = "https://213.157.47.86:8000/chat"
# url = "http://point1.kazprom.com:8000/chat"
url = "https://point1.kazprom.com:8000/chat"
payload = {"text": "Сколько стоит Арматура 20 ?"}

# Отключаем предупреждения об отсутствии SSL-сертификата (если используете verify=False)
#urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}

try:
    # response = requests.post(url, json=payload, timeout=15)
    # response = requests.post(url, json=payload, headers=headers, timeout=(15, 300), verify=False)
    response = requests.post(url, json=payload, headers=headers, timeout=(15, 300))
    # print(f"Статус-код: {response.status_code}")
    # response.raise_for_status()
    print(response.text)

    print("Ответ сервера:", response.text)  # response.json())
except requests.exceptions.ConnectTimeout as e:
    print(f"Сервер вообще недоступен: {e}")
except requests.exceptions.ReadTimeout as e:
    print(f"Сервер принял запрос, но бот не успел ответить: {e}")
except requests.exceptions.RequestException as e:
    print(f"Не удалось связаться с сервером: {e}")
except Exception as e:
    print(f"except webchat1test: {e}")
