import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtUiTools import QUiLoader
from PySide6.QtCore import QFile


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Создаем загрузчик интерфейса
        loader = QUiLoader()

        # Открываем UI-файл
        ui_file = QFile("ui/main.ui")
        ui_file.open(QFile.ReadOnly)

        # Загружаем интерфейс во внутренний виджет
        self.ui = loader.load(ui_file, self)
        ui_file.close()

        # Устанавливаем загруженный виджет как центральный
        self.setCentralWidget(self.ui)

        # # Обращаемся к кнопке по имени (Object Name из Qt Designer)
        # self.ui.myButton.clicked.connect(self.on_click)

    def on_click(self):
        print("Кнопка нажата!")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
