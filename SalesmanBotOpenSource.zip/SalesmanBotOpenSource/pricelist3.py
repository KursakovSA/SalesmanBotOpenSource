import xlrd


class PriceListManager:
    def __init__(self):
        self.products = {}

    def load_from_excel(self, file_path, sheet_index=0):
        """Загружает данные из .xls файла"""
        try:
            # Открываем книгу
            workbook = xlrd.open_workbook(file_path)
            sheet = workbook.sheet_by_index(sheet_index)

            # Предполагаем структуру: 0: Название, 1: Цена
            for row_idx in range(1, sheet.nrows):  # Пропускаем заголовок
                row = sheet.row_values(row_idx)
                name = str(row[0]).strip()
                try:
                    price = float(row[1])
                    self.products[name] = price
                except (ValueError, IndexError):
                    print(f"Ошибка в строке {row_idx}: неверный формат цены")

            print(f"Загружено позиций: {len(self.products)}")

        except FileNotFoundError:
            print("Файл не найден.")
        except Exception as e:
            print(f"Произошла ошибка: {e}")

    def get_price(self, product_name):
        """Возвращает цену по названию товара"""
        return self.products.get(product_name, "Товар не найден")

    def list_all(self):
        """Выводит весь прайс-лист"""
        for name, price in self.products.items():
            print(f"{name}: {price:.2f}")


# Пример использования:
pm = PriceListManager()
pm.load_from_excel('price/price.xlsx')
print(pm.get_price('Кирпич'))
# pm.list_all()
