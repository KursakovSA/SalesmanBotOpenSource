# origin - 07.05.2026, last edit - 31.05.2026
import dal
import log
import chat
import price
import rest
# import tkinterGUI

# global vars
price_list = []
rest_list = []


def main():
    # origin - 07.05.2026, last edit - 02.06.2026
    try:
        get_init()
        
        # tkinterGUI.get()
        
        get_new_chat("PC")
        # get_new_chat("Web")
        # get_new_chat("WA")
        # get_new_chat("TG")

    except Exception as e:
        log.flush_except(f"except app.main(): {e}")


def get_new_chat(chatType) -> None:
    # origin - 31.05.2026, last edit - 31.05.2026
    try:
        log.flush_chat(" ")
        log.flush_chat(" Start agent.")
        print("Start agent.")
        while True:
            chat.get_chat(chat.get_agent(), chatType)
            user_input = input("End agent (empty input) ?")

            if not user_input:
                break

        print("End agent.")
        log.flush_chat(" End agent.")
        log.flush_chat(" ")
    except Exception as e:
        log.flush_except(f"except app.get_new(): {e}")


def get_init() -> None:
    # origin - 07.05.2026, last edit - 30.05.2026
    try:
        dal.get_init_work_database()
        price.get_price_list()  # TOTHINK
        rest.get_rest_list()  # TOTHINK
    except Exception as e:
        log.flush_except(f"except app.get_init(): {e}")


# main
if __name__ == "__main__":
    main()
