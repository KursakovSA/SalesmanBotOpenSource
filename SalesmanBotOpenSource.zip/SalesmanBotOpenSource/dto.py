from dataclasses import dataclass
import log


@dataclass
class Dto:
    # origin - 26.05.2026, last edit - 29.05.2026
    src: str = ""
    dtoId: str = ""
    parent: str = ""
    face1: str = ""
    face2: str = ""
    face: str = ""
    sliceId: str = ""
    code: str = ""
    description: str = ""
    geo: str = ""
    sign: str = ""
    account: str = ""
    process: str = ""
    asset: str = ""
    deal: str = ""
    role: str = ""
    info: str = ""
    meter: str = ""
    meterValue: str = ""
    unit: str = ""
    more: str = ""
    mark: str = ""

    def __str__(self):
        # origin - 26.05.2026, last edit - 29.05.2026
        res = ""
        try:
            res = res+log.add_if_not_empty("src ", self.src)
            res = res+log.add_if_not_empty(", dtoId ", self.dtoId)
            res = res+log.add_if_not_empty(", parent ", self.parent)
            res = res+log.add_if_not_empty(", face1 ", self.face1)
            res = res+log.add_if_not_empty(", face2 ", self.face2)
            res = res+log.add_if_not_empty(", face ", self.face)
            res = res+log.add_if_not_empty(", sliceId ", self.sliceId)
            res = res+log.add_if_not_empty(", code ", self.code)
            res = res+log.add_if_not_empty(", description ", self.description)
            res = res+log.add_if_not_empty(", geo ", self.geo)
            res = res+log.add_if_not_empty(", sign ", self.sign)
            res = res+log.add_if_not_empty(", account ", self.account)
            res = res+log.add_if_not_empty(", process ", self.process)
            res = res+log.add_if_not_empty(", asset ", self.asset)
            res = res+log.add_if_not_empty(", deal ", self.deal)
            res = res+log.add_if_not_empty(", role ", self.role)
            res = res+log.add_if_not_empty(", info ", self.info)
            res = res+log.add_if_not_empty(", meter ", self.meter)
            res = res+log.add_if_not_empty(", meterValue ", self.meterValue)
            res = res+log.add_if_not_empty(", unit ", self.unit)
            res = res+log.add_if_not_empty(", more ", self.more)
            res = res+log.add_if_not_empty(", mark ", self.mark)
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except dto.__str__(self): {e}")
        return res


@staticmethod
def initdto1(src):  # TODO
    # origin - 26.05.2026, last edit - 29.05.2026
    res = Dto()
    try:
        res.src = src
        res.src1 = src.replace(" ", "")
        items = res.src1.split(",")
        if (len(items) >= 1):
            res.date1 = items[0]
        if (len(items) >= 2):
            res.lastLineTitle = items[1]
        if (len(items) >= 3):
            res.productName = items[2]
        if (len(items) >= 4):
            res.productUnit = items[3]
        if (len(items) >= 5):
            res.priceValue1 = items[4]
        if (len(items) >= 6):
            res.priceValue2 = items[5]
        if (len(items) >= 7):
            res.productDescription = items[6]
        if (len(items) >= 8):
            res.productGroup = items[7]
    except Exception as e:
        log.flush_except(f"except initdto1(str): {e}")
    return res


@staticmethod
def testdto1():
    # origin - 26.05.2026, last edit - 29.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("testdto1()")  # TODO
        for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                    "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
            log.flush_test("initdto1(str), res=" +
                           str(initdto1(tmp))+", tmp="+tmp)
    except Exception as e:
        log.flush_except(f"except dto.test(): {e}")
