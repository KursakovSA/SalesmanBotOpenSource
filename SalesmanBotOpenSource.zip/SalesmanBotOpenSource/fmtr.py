import app


def add_if_empty(strNote, strValue):
    # origin - 26.05.2026, last edit - 26.05.2026
    res = ""
    strValue = strValue.strip()
    try:
        if not strValue:
            res = strNote+strValue
    except Exception as e:
        app.flush_log_except(f"except fmtr.add_if_empty(2str): {e}")
    return res


def add_if_not_empty(strNote, strValue):
    # origin - 26.05.2026, last edit - 26.05.2026
    res = ""
    strValue = strValue.strip()
    try:
        if strValue:
            res = strNote+strValue
    except Exception as e:
        app.flush_log_except(f"except fmtr.add_if_not_empty(2str): {e}")
    return res


@staticmethod
def test():
    # origin - 26.05.2026, last edit - 26.05.2026
    try:
        pass
        # app.flush_log_test(" ")
        # app.flush_log_test("fmtr.add_if_empty.test()")
        # for tmp1 in [" empty code "]:
        #     for tmp2 in ["", " ", "  ", " codeValue", "codeValue"]:
        #         app.flush_log_test("fmtr.add_if_empty(2str), res=" +
        #                            add_if_empty(tmp1, tmp2)+" tmp1="+tmp1+" tmp2="+tmp2)

        # app.flush_log_test(" ")
        # app.flush_log_test("fmtr.add_if_not_empty.test()")
        # for tmp1 in [" code "]:
        #     for tmp2 in ["", " ", "  ", " codeValue", "codeValue"]:
        #         app.flush_log_test("fmtr.add_if_not_empty(2str), res=" +
        #                            add_if_not_empty(tmp1, tmp2)+" tmp1="+tmp1+" tmp2="+tmp2)

    except Exception as e:
        app.flush_log_except(f"except fmtr.test(): {e}")
