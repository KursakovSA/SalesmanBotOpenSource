# listen443.ps1 - TCP listener on 443 to test the chain. Run as ADMIN.
$port = 443
New-NetFirewallRule -DisplayName "Test 443" -Direction Inbound -LocalPort $port -Protocol TCP -Action Allow -ErrorAction SilentlyContinue | Out-Null

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $port)
$listener.Start()
Write-Host "Listening on TCP :$port  (Ctrl+C to exit)..." -ForegroundColor Green
while ($true) {
    $client = $listener.AcceptTcpClient()
    $remote = $client.Client.RemoteEndPoint
    Write-Host ("[{0}] connection from {1}" -f (Get-Date -Format HH:mm:ss), $remote) -ForegroundColor Cyan
    try {
        $s = $client.GetStream()
        $b = [Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 OK`r`nContent-Type: text/plain`r`nConnection: close`r`n`r`nOK 443 chain works`r`n")
        $s.Write($b,0,$b.Length); $s.Flush()
    } catch {}
    $client.Close()
}