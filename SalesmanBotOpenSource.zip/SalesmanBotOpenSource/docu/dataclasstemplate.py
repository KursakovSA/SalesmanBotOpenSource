# origin - 23.05.2026, last edit - 28.05.2026
from dataclasses import dataclass, field
import fmtr
import log


@dataclass
class DataClassTemplate:
    # origin - 24.05.2026, last edit - 28.05.2026
    listDelStr = [" "]  # static field
    src0: str = ""
    src1: str = ""
    defect: str = ""
    date1: str = ""
    options: dict = field(default_factory=dict)

    def __init__(self):
        pass

    def __str__(self):
        # origin - 24.05.2026, last edit - 28.05.2026
        res = ""
        try:
            res = res+fmtr.add_if_not_empty("src0 ", str(self.src0))
            res = res+fmtr.add_if_not_empty(", src1 ", str(self.src1))
            res = res+fmtr.add_if_not_empty(", defect ", str(self.defect))
            res = res+fmtr.add_if_not_empty(", date1 ", str(self.date1))
            res = res+fmtr.add_if_not_empty(", options ", str(self.options))
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except dataclasstemplate.__str__(self): {e}")
        return res


@staticmethod
def init1(src):
    # origin - 24.05.2026, last edit - 28.05.2026
    res = DataClassTemplate()
    try:
        res.src0 = src
        res.src1 = src.replace(" ", "")
        items = res.src1.split(",")
        if (len(items) >= 1):
            res.date1 = items[0]
        if (len(items) >= 2):
            res.lastLineTitle = items[1]
        if (len(items) >= 3):
            res.productName = items[2]
        if (len(items) >= 4):
            res.productUnit = items[3]
        if (len(items) >= 5):
            res.priceValue1 = items[4]
        if (len(items) >= 6):
            res.priceValue2 = items[5]
        if (len(items) >= 7):
            res.productDescription = items[6]
        if (len(items) >= 8):
            res.productGroup = items[7]
    except Exception as e:
        log.flush_except(f"except dataclasstemplate.init1(str): {e}")
    return res


@staticmethod
def test():
    # origin - 19.05.2026, last edit - 28.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("dataclasstemplate.test()")
        for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                    "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
            log.flush_test("dataclasstemplate.init1(str), res=" +
                           str(init1(tmp))+", tmp="+tmp)
    except Exception as e:
        log.flush_except(f"except dataclasstemplate.test(): {e}")
