# origin - 23.05.2026, last edit - 27.05.2026
from dataclasses import dataclass
import app
import fmtr
import log


@dataclass
class DataClassTemplate:
    # origin - 24.05.2026, last edit - 27.05.2026
    listDelStr = [" "]  # static field
    src0: str = ""
    src1: str = ""
    defect: str = ""
    date1: str = ""
    lastLineTitle: str = ""
    productName: str = ""
    productUnit: str = ""
    priceValue1: str = ""
    priceValue2: str = ""
    productDescription: str = ""
    productGroup: str = ""

    def __init__(self):
        pass

    # @staticmethod
    def get1(src):
        # origin - 24.05.2026, last edit - 27.05.2026
        res = DataClassTemplate()
        try:
            res.src0 = src
            res.src1 = src.replace(" ", "")
            items = res.src1.split(",")
            if (len(items) >= 1):
                res.date1 = items[0]
            if (len(items) >= 2):
                res.lastLineTitle = items[1]
            if (len(items) >= 3):
                res.productName = items[2]
            if (len(items) >= 4):
                res.productUnit = items[3]
            if (len(items) >= 5):
                res.priceValue1 = items[4]
            if (len(items) >= 6):
                res.priceValue2 = items[5]
            if (len(items) >= 7):
                res.productDescription = items[6]
            if (len(items) >= 8):
                res.productGroup = items[7]
        except Exception as e:
            log.flush_except(f"except dataclasstemplate.get1(src): {e}")
        return res

    def __str__(self):
        # origin - 24.05.2026, last edit - 27.05.2026
        res = ""
        try:
            res = res+fmtr.add_if_not_empty("src0 ", self.src0)
            res = res+fmtr.add_if_not_empty(", src1 ", self.src1)
            res = res+fmtr.add_if_not_empty(", defect ", self.defect)
            res = res+fmtr.add_if_not_empty(", date1 ", self.date1)
            res = res+fmtr.add_if_not_empty(", lastLineTitle ", self.lastLineTitle)
            res = res+fmtr.add_if_not_empty(", productName ", self.productName)
            res = res+fmtr.add_if_not_empty(", productUnit ", self.productUnit)
            res = res+fmtr.add_if_not_empty(", priceValue1 ", self.priceValue1)
            res = res+fmtr.add_if_not_empty(", priceValue2 ", self.priceValue2)
            res = res+fmtr.add_if_not_empty(", productDescription ", self.productDescription)
            res = res+fmtr.add_if_not_empty(", productGroup ", self.productGroup)
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except dataclasstemplate.__str__(self): {e}")
        return res


@staticmethod
def test():
    # origin - 19.05.2026, last edit - 27.05.2026
    try:
        app.flush_log_test(" ")
        app.flush_log_test("dataclasstemplate.test()")
        for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                    "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
            log.flush_test("dataclasstemplate.get1(str), res=" +
                           str(DataClassTemplate.get1(tmp))+", tmp="+tmp)
    except Exception as e:
        log.flush_except(f"except dataclasstemplate.test(): {e}")
