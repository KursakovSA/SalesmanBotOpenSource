# listen-ports.ps1 - TCP listener on multiple ports. Run as ADMIN.
# Default: 80 and 443. Custom set:  .\listen-ports.ps1 -Ports 80,443,8443
param(
    [int[]] $Ports = @(80, 443)
)

foreach ($p in $Ports) {
    New-NetFirewallRule -DisplayName "Test $p" -Direction Inbound -LocalPort $p -Protocol TCP -Action Allow -ErrorAction SilentlyContinue | Out-Null
}

$listeners = @{}
foreach ($p in $Ports) {
    $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $p)
    $l.Start()
    $listeners[$p] = $l
}
Write-Host ("Listening on TCP ports: {0}  (Ctrl+C to exit)..." -f ($Ports -join ", ")) -ForegroundColor Green

while ($true) {
    $idle = $true
    foreach ($p in $Ports) {
        $l = $listeners[$p]
        if ($l.Pending()) {
            $idle = $false
            $client = $l.AcceptTcpClient()
            $remote = $client.Client.RemoteEndPoint
            Write-Host ("[{0}] :{1} connection from {2}" -f (Get-Date -Format HH:mm:ss), $p, $remote) -ForegroundColor Cyan
            try {
                $s = $client.GetStream()
                $b = [Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 OK`r`nContent-Type: text/plain`r`nConnection: close`r`n`r`nOK: $p chain works`r`n")
                $s.Write($b,0,$b.Length); $s.Flush()
            } catch {}
            $client.Close()
        }
    }
    if ($idle) { Start-Sleep -Milliseconds 100 }
}