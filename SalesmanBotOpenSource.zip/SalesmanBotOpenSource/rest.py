import log

def get_rest_list() -> []:  # TODO
    # origin - 07.05.2026, last edit - 27.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log.flush_except(f"except rest.get_rest_list(): {e}")
    return res