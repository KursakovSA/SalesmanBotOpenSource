import asyncio
import os
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from agno.agent import Agent
from agno.models.ollama import Ollama

# Инициализация агента Agno
ai_agent = Agent(
    model=Ollama(id="llama3.2"),
    description="Вы — полезный ИИ-ассистент в Telegram.",
    markdown=True
)

# Инициализация Telegram-бота
TOKEN = os.getenv("TELEGRAM_TOKEN", "ВАШ_ТГ_ТОКЕН_ЗДЕСЬ")
bot = Bot(token=TOKEN)
dp = Dispatcher()

@dp.message(CommandStart())
async def start_cmd(message: types.Message):
    await message.answer("Привет! Я ИИ-ассистент на базе Agno и Ollama. Задавай любой вопрос.")

@dp.message()
async def handle_message(message: types.Message):
    # Показываем статус "печатает", пока локальная LLM генерирует ответ
    await bot.send_chat_action(chat_id=message.chat.id, action="typing")
    
    try:
        # Запрашиваем ответ у агента Agno (синхронный вызов запускаем в executor, чтобы не блочить бота)
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None, 
            lambda: ai_agent.get_response(message.text)
        )
        
        # Отправляем текстовый ответ пользователю
        await message.answer(response.content, parse_mode="Markdown")
        
    except Exception as e:
        await message.answer(f"Произошла ошибка при обращении к LLM: {str(e)}")

async def main():
    print("Бот запущен через aiogram...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
