# origin - 30.05.2026, last edit - 30.05.2026
import sqlite3
import tkinter as tk
from tkinter import ttk


def get():
    root = tk.Tk()
    root.title("Просмотр БД")

    # --- НАСТРОЙКА СТИЛЯ ДЛЯ ГРАНИЦ СЕТКИ ---
    style = ttk.Style()
    style.theme_use("clam")  # Тема 'clam' лучше всего поддерживает кастомизацию границ

    style.configure(
        "Treeview",
        background="white",
        foreground="black",
        rowheight=25,
        fieldbackground="white",
        borderwidth=2,
    )

    # Включаем отображение вертикальных и горизонтальных линий (cell)
    style.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
    style.configure("Treeview", rowheight=25, gridlines=True)

    # Альтернативный и самый надежный способ включить сетку в ttk:
    # Мы настраиваем параметры отображения линий
    root.option_add("*Treeview.Gridlines", "both")

    # --- СОЗДАНИЕ ТАБЛИЦЫ ---
    # Передаем show="headings", чтобы скрыть пустую первую колонку
    tree = ttk.Treeview(
        root,
        columns=("Id", "Parent", "Date1", "Date2", "Code", "Description", "More"),
        show="headings",
    )

    # Названия колонок
    tree.heading("Id", text="Id")
    tree.heading("Parent", text="Parent")
    tree.heading("Date1", text="Date1")
    tree.heading("Date2", text="Date2")  # Добавлено, так как в columns оно есть
    tree.heading("Code", text="Code")
    tree.heading("Description", text="Description")
    tree.heading("More", text="More")

    # --- РАСТЯГИВАНИЕ КОЛОНОК ---
    # Чтобы колонки меняли размер вместе с окном, используем stretch=True
    for col in tree["columns"]:
        tree.column(col, anchor="center", width=100, minwidth=50, stretch=True)

    # --- ДОБАВЛЕНИЕ ВЕРТИКАЛЬНОГО СКРОЛЛБАРА ---
    scrollbar_y = ttk.Scrollbar(root, orient=tk.VERTICAL, command=tree.yview)
    tree.configure(yscrollcommand=scrollbar_y.set)

    # --- ПРАВИЛЬНАЯ УПАКОВКА ДЛЯ РАСТЯГИВАНИЯ ---
    # Сначала размещаем скроллбар справа, растягивая его по высоте
    scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)

    # Размещаем таблицу и заставляем её заполнять всё окно
    tree.pack(fill=tk.BOTH, expand=True)

    # --- РАСТЯГИВАНИЕ СЕТКИ ПРИ ИЗМЕНЕНИИ ОКНА ---
    # Настраиваем веса строк и колонок главного окна
    root.grid_rowconfigure(0, weight=1)
    root.grid_columnconfigure(0, weight=1)

    # --- ЗАГРУЗКА ДАННЫХ ИЗ SQLITE ---
    try:
        conn = sqlite3.connect("db/MyWorkBase1.sqlite3")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM role")
        for row in cursor.fetchall():
            tree.insert("", tk.END, values=row)
        conn.close()
    except sqlite3.OperationalError:
        print("База данных не найдена.")

    root.mainloop()


if __name__ == "__main__":
    get()


# def get():
#     # origin - 30.05.2026, last edit - 30.05.2026
#     # Инициализация окна
#     root = tk.Tk()
#     root.title("Просмотр БД")

#     # Создание таблицы
#     tree = ttk.Treeview(root, columns=("Id", "Parent", "Date1", "Date2",
#                                        "Code", "Description", "More"), show="headings")
#     tree.heading("Id", text="Id")
#     tree.heading("Parent", text="Parent")
#     tree.heading("Date1", text="Date1")
#     tree.heading("Code", text="Code")
#     tree.heading("Description", text="Description")
#     tree.heading("More", text="More")
#     tree.pack(fill=tk.BOTH, expand=True)
#     # Загрузка данных из SQLite
#     conn = sqlite3.connect("db/MyWorkBase1.sqlite3")
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM role")
#     for row in cursor.fetchall():
#         tree.insert("", tk.END, values=row)
#     conn.close()
#     root.mainloop()
