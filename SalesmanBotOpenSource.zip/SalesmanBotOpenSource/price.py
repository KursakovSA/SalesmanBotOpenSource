# origin - 11.05.2026, last edit - 28.06.2026
# import openpyxl
import log
# from thefuzz import process
import thefuzz
import csv

def get_pricelistdescription(src: str) -> dict: #TODO
    # origin - 29.06.2026, last edit - 30.06.2026
    res = {}
    try:
        pass
        # items = src.split(",")
        # if (len(items) >= 1):
        #     res["date1"] = str(items[0]).strip()
        # if (len(items) >= 2):
        #     res["lastLineTitle"] = str(items[1]).strip()
    except Exception as e:
        log.flush_except(f"except price.get_pricelistdescription(str): {e}")
    return res

def get_pricelistmap(src: str) -> dict:
    # origin - 27.06.2026, last edit - 30.06.2026
    res = {}
    try:
        items = src.split(",")
        if (len(items) >= 1):
            res["date1"] = str(items[0]).strip()
        if (len(items) >= 2):
            res["lastLineTitle"] = str(items[1]).strip()
        if (len(items) >= 3):
            res["productName"] = str(items[2]).strip()
        if (len(items) >= 4):
            res["productUnit"] = str(items[3]).strip()
        if (len(items) >= 5):
            res["priceValue1"] = str(items[4]).strip()
        if (len(items) >= 6):
            res["priceValue2"] = str(items[5]).strip()
        if (len(items) >= 7):
            res["productDescription"] = str(items[6]).strip()
    except Exception as e:
        log.flush_except(f"except price.get_pricelistmap(str): {e}")
    return res

# def load_price(self, sheet_name=None):
#     # origin - 11.05.2026, last edit - 27.06.2026
#     try:
#         # data_only=True позволяет читать значения, а не формулы
#         workbook = openpyxl.load_workbook(self.file_path, data_only=True)
#         sheet = workbook[sheet_name] if sheet_name else workbook.active

#         # Читаем строки, начиная со второй (пропуская заголовок)
#         for row in sheet.iter_rows(min_row=2, values_only=True):
#             # Пропускаем пустые строки
#             if not any(row):
#                 continue

#             # Пример структуры: Название, Артикул, Цена
#             item = {
#                 "name": row[0],
#                 "sku": row[1],
#                 "price": row[2]
#             }
#             self.data.append(item)

#             print(f"Загружено позиций: {len(self.data)}")
#     except Exception as e:
#         log.flush_except(f"except price.load_price(self, str): {e}")


# def get_price_by_name(self, name):
#     # origin - 11.05.2026, last edit - 27.06.2026
#     try:
#         for item in self.data:
#             if item['name'] == name:
#                 return item['price']
#     except Exception as e:
#         log.flush_except(f"except price.get_price_by_name(self, str): {e}")
#         return None


def get(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 28.06.2026
    res = ""
    try:
        if not product_name:
            return res

        res = get_product_price_exact(product_name)

        # если не нашли по точному наим-ю товара, ищем по нечеткому поиску
        if not res:
            res = get_product_price_fuzz(product_name)

        if not res:
            res = "Товар " + product_name + " не найден в прайс-листе."
    except Exception as e:
        log.flush_except(f"except price.get(str): {product_name} {e}")
    return res


def get_product_price_exact(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 27.06.2026
    res = ""
    try:
        if not product_name:
            return res

        with open('price/price.csv', mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                if row['Name'].lower() == product_name.lower():
                    res = f"Цена товара '{row['Name']
                                          }' составляет {row['Price']}."
                    break
    except Exception as e:
        log.flush_except(f"except price.get_product_price_exact(str): {product_name} {e}")
    return res


def get_product_price_fuzz(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 27.06.2026
    res = ""
    try:
        if not product_name:
            return res

        # score_cutoff=70 означает, что сходство должно быть не ниже 70%
        data = list(csv.DictReader('price/price.csv', delimiter=';'))
        names = [row['Name'] for row in data]
        best_match, score = thefuzz.process.extractOne(
            product_name, names, score_cutoff=70) or (None, 0)

        if best_match:
            # Находим цену для найденного похожего товара
            price = next(row['Price']
                         for row in data if row['Name'] == best_match)
            res = f"Точное совпадение не найдено. Возможно, вы имели в виду '{
                best_match}'? Его цена — {price}."

    except Exception as e:
        log.flush_except(f"except price.get_product_price_fuzz(str): {product_name} {e}")
    return res


# def get_price_list() -> list:  # TODO
#     # origin - 28.05.2026, last edit - 28.06.2026
#     res = []
#     try:
#         pass
#     except Exception as e:
#         log.flush_except(f"except price.get_price_list(): {e}")
#     return res


def test():
    # origin - 24.05.2026, last edit - 27.06.2026
    try:
        log.flush_test(" ")

        log.flush_test("price.get(str)")
        for tmp in ["Арматура 20", "Арматура 12", "Арматур 20", "Арматур", "арматура 20", "Арматура", "Арматура 6788", "тра-ла-ла", "Лист 5"]:
            log.flush_test("price.get(), res=" +
                           str(get(tmp))+", tmp="+tmp)

        log.flush_test("price.get_pricelistmap(str)")
        for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                    "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
            log.flush_test("price.get_pricelistmap(str), res=" +
                           str(get_pricelistmap(tmp))+", tmp="+tmp)

    except Exception as e:
        log.flush_except(f"except price.test(): {e}")
