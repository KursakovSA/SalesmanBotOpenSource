# origin - 11.05.2026, last edit - 29.05.2026
import openpyxl
import log
from thefuzz import process
import csv
from dataclasses import dataclass


@staticmethod
def load_price(self, sheet_name=None):
    # origin - 11.05.2026, last edit - 29.05.2026
    try:
        # data_only=True позволяет читать значения, а не формулы
        workbook = openpyxl.load_workbook(self.file_path, data_only=True)
        sheet = workbook[sheet_name] if sheet_name else workbook.active

        # Читаем строки, начиная со второй (пропуская заголовок)
        for row in sheet.iter_rows(min_row=2, values_only=True):
            # Пропускаем пустые строки
            if not any(row):
                continue

            # Пример структуры: Название, Артикул, Цена
            item = {
                "name": row[0],
                "sku": row[1],
                "price": row[2]
            }
            self.data.append(item)

            print(f"Загружено позиций: {len(self.data)}")
    except Exception as e:
        log.flush_except(f"except price.load_price(self, str): {e}")


# @staticmethod
# def get_price_by_sku(self, sku):
#     # origin - 11.05.2026, last edit - 29.05.2026
#     try:
#         for item in self.data:
#             if item['sku'] == sku:
#                 return item['price']
#     except Exception as e:
#         log.flush_except(f"except price.get_price_by_sku(self, str): {e}")
#         return None


@staticmethod
def get_price_by_name(self, name):
    # origin - 11.05.2026, last edit - 29.05.2026
    try:
        for item in self.data:
            if item['name'] == name:
                return item['price']
    except Exception as e:
        log.flush_except(f"except price.get_price_by_name(self, str): {e}")
        return None


@dataclass
class PriceListMap:
    # origin - 19.05.2026, last edit - 29.05.2026
    listDelStr = [" "]  # static field
    src0: str = ""
    src1: str = ""
    defect: str = ""
    date1: str = ""
    lastLineTitle: str = ""
    productName: str = ""
    productUnit: str = ""
    priceValue1: str = ""
    priceValue2: str = ""
    productDescription: str = ""
    productGroup: str = ""

    def __str__(self):
        # origin - 19.05.2026, last edit - 28.05.2026
        res = ""
        try:
            res = res+log.add_if_not_empty("src0 ", self.src0)
            res = res+log.add_if_not_empty(", src1 ", self.src1)
            res = res+log.add_if_not_empty(", defect ", self.defect)
            res = res+log.add_if_not_empty(", date1 ", self.date1)
            res = res+log.add_if_not_empty(", lastLineTitle ", self.lastLineTitle)
            res = res+log.add_if_not_empty(", productName ", self.productName)
            res = res+log.add_if_not_empty(", productUnit ", self.productUnit)
            res = res+log.add_if_not_empty(", priceValue1 ", self.priceValue1)
            res = res+log.add_if_not_empty(", priceValue2 ", self.priceValue2)
            res = res+log.add_if_not_empty(", productDescription ", self.productDescription)
            res = res+log.add_if_not_empty(", productGroup ", self.productGroup)
            res = "{"+res+"}"
        except Exception as e:
            log.flush_except(f"except pricelistmap.__str__(): {e}")
        return res


@staticmethod
def initpricelistmap1(src):
    # origin - 19.05.2026, last edit - 29.05.2026
    res = PriceListMap()
    try:
        res.src0 = src
        res.src1 = src.replace(" ", "")
        items = res.src1.split(",")
        if (len(items) >= 1):
            res.date1 = items[0]
        if (len(items) >= 2):
            res.lastLineTitle = items[1]
        if (len(items) >= 3):
            res.productName = items[2]
        if (len(items) >= 4):
            res.productUnit = items[3]
        if (len(items) >= 5):
            res.priceValue1 = items[4]
        if (len(items) >= 6):
            res.priceValue2 = items[5]
        if (len(items) >= 7):
            res.productDescription = items[6]
        if (len(items) >= 8):
            res.productGroup = items[7]
    except Exception as e:
        log.flush_except(f"except price.initpricelistmap1(): {e}")
    return res


# @staticmethod
def get_product_price(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 28.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        res = get_product_price_exact(product_name)

        # если не нашли по точному наим-ю товара, ищем по нечеткому поиску
        if not res:
            res = get_product_price_fuzz(product_name)

        if not res:
            res = "Товар " + product_name + " не найден в прайс-листе."
    except Exception as e:
        log.flush_except(f"except price.get_product_price(str): {product_name} {e}")
    return res


# @staticmethod
def get_product_price_exact(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 01.06.2026
    res = "?"
    try:
        if not product_name:
            return res

        with open('price/price.csv', mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            for row in reader:
                if row['Name'].lower() == product_name.lower():
                    res = f"Цена товара '{row['Name']
                                          }' составляет {row['Price']}."
                    break
    except Exception as e:
        log.flush_except(f"except price.get_product_price_exact(str): {product_name} {e}")
    return res


# @staticmethod
def get_product_price_fuzz(product_name: str) -> str:
    # origin - 28.05.2026, last edit - 31.05.2026
    res = "?"
    try:
        if not product_name:
            return res

        # score_cutoff=70 означает, что сходство должно быть не ниже 70%
        data = list(csv.DictReader('price/price.csv'))
        names = [row['Name'] for row in data]
        best_match, score = process.extractOne(
            product_name, names, score_cutoff=70) or (None, 0)

        if best_match:
            # Находим цену для найденного похожего товара
            price = next(row['Price']
                         for row in data if row['Name'] == best_match)
            res = f"Точное совпадение не найдено. Возможно, вы имели в виду '{
                best_match}'? Его цена — {price}."
    except Exception as e:
        log.flush_except(f"except price.get_product_price_fuzz(str): {product_name} {e}")
    return res


@staticmethod
def get_price_list() -> []:  # TODO
    # origin - 28.05.2026, last edit - 28.05.2026
    res = []
    try:
        pass
    except Exception as e:
        log.flush_except(f"except price.get_price_list(): {e}")
    return res


@staticmethod
def test():
    # origin - 24.05.2026, last edit - 29.05.2026
    try:
        log.flush_test(" ")
        log.flush_test("price.test()")

        log.flush_test("price.initpricelistmap1(str).test()")
        for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                    "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
            log.flush_test("price.initpricelistmap1(str), res=" +
                           str(initpricelistmap1(tmp))+", tmp="+tmp)

    except Exception as e:
        log.flush_except(f"except price.test(): {e}")
