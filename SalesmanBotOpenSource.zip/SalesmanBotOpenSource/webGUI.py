import streamlit as st
import pandas as pd
import sqlite3

# Настройка страницы
st.set_page_config(layout="wide")
st.title("Управление базой данных")

# Подключение к БД и загрузка данных
conn = sqlite3.connect("db/MyWorkBase1.sqlite3")
df = pd.read_sql_query("SELECT * FROM role", conn)

# Интерактивная таблица с возможностью редактирования
edited_df = st.data_editor(df, num_rows="dynamic")

# Кнопка сохранения изменений обратно в БД
if st.button("Сохранить изменения"):
    edited_df.to_sql("users", conn, if_exists="replace", index=False)
    st.success("Данные успешно обновлены!")

conn.close()

# Блок автоматического запуска из-под обычной Python-консоли
if __name__ == '__main__':
    # import os
    import sys
    from streamlit.web import cli as stcli

    if not sys.argv[0].endswith("streamlit"):
        sys.argv = ["streamlit", "run", __file__]
        sys.exit(stcli.main())
