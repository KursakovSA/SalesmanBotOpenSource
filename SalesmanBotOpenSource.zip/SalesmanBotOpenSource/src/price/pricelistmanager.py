import openpyxl
from app import flush_log_except


class PriceListManager:
    # origin - 11.05.2026, last edit - 11.05.2026
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = []

    def load_price(self, sheet_name=None):
        # origin - 11.05.2026, last edit - 11.05.2026
        try:
            # data_only=True позволяет читать значения, а не формулы
            workbook = openpyxl.load_workbook(self.file_path, data_only=True)
            sheet = workbook[sheet_name] if sheet_name else workbook.active

            # Читаем строки, начиная со второй (пропуская заголовок)
            for row in sheet.iter_rows(min_row=2, values_only=True):
                # Пропускаем пустые строки
                if not any(row):
                    continue

                # Пример структуры: Название, Артикул, Цена
                item = {
                    "name": row[0],
                    "sku": row[1],
                    "price": row[2]
                }
                self.data.append(item)

            print(f"Загружено позиций: {len(self.data)}")
        except Exception as e:
            flush_log_except(f"except load_price(): {e}")

    def get_price_by_sku(self, sku):

        # origin - 11.05.2026, last edit - 11.05.2026
        try:
            for item in self.data:
                if item['sku'] == sku:
                    return item['price']
        except Exception as e:
            flush_log_except(f"except get_price_by_sku(): {e}")
        return None

    def get_price_by_name(self, name):
        # origin - 11.05.2026, last edit - 11.05.2026
        try:
            for item in self.data:
                if item['name'] == name:
                    return item['price']
        except Exception as e:
            flush_log_except(f"except get_price_by_name(): {e}")
        return None


# Пример использования:
plm = PriceListManager("price_data/price.xlsx")
plm.load_price()
print(f"get_price_by_sku('A100')={plm.get_price_by_sku('A100')}")
print(f"get_price_by_name('Арматура 6')={plm.get_price_by_name('Арматура 6')}")
