from dataclasses import dataclass


@dataclass
class PriceListMap:
    # origin - 19.05.2026, last edit - 19.05.2026
    listDelStr = [" "]  # static field
    src0: str = ""
    src1: str = ""
    defect: str = ""
    date1: str = ""
    lastLineTitle: str = ""
    productName: str = ""
    productUnit: str = ""
    priceValue1: str = ""
    priceValue2: str = ""
    productDescription: str = ""
    productGroup: str = ""

    def __init__(self):
        pass

    # @staticmethod
    def get1(src):
        # origin - 19.05.2026, last edit - 20.05.2026
        res = PriceListMap()
        res.src0 = src
        res.src1 = src.replace(" ", "")
        items = res.src1.split(",")
        if (len(items) >= 1):
            res.date1 = items[0]
        if (len(items) >= 2):
            res.lastLineTitle = items[1]
        if (len(items) >= 3):
            res.productName = items[2]
        if (len(items) >= 4):
            res.productUnit = items[3]
        if (len(items) >= 5):
            res.priceValue1 = items[4]
        if (len(items) >= 6):
            res.priceValue2 = items[5]
        if (len(items) >= 7):
            res.productDescription = items[6]
        if (len(items) >= 8):
            res.productGroup = items[7]
        return res

    def __str__(self):
        # origin - 19.05.2026, last edit - 20.05.2026
        res = ""
        res = res+"src0 "+self.src0
        res = res+", src1 "+self.src1
        res = res+", defect "+self.defect
        res = res+", date1 "+self.date1
        res = res+", lastLineTitle "+self.lastLineTitle
        res = res+", productName "+self.productName
        res = res+", productUnit "+self.productUnit
        res = res+", priceValue1 "+self.priceValue1
        res = res+", priceValue2 "+self.priceValue2
        res = res+", productDescription "+self.productDescription
        res = res+", productGroup "+self.productGroup
        res = "{"+res+"}"
        return res

    # @staticmethod
    def test():
        # origin - 19.05.2026, last edit - 19.05.2026
        for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                    "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
            print(PriceListMap.get1(tmp))


PriceListMap.test()
