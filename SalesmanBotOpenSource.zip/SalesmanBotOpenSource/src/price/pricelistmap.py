from dataclasses import dataclass


@dataclass
class PriceListMap:
    # origin - 19.05.2026, last edit - 19.05.2026
    listDelStr = [" "]  # static field
    src0: str = ""
    src1: str = ""
    defect: str = ""
    date1: str = ""
    lastLineTitle: str = ""
    productName: str = ""
    productUnit: str = ""
    priceValue1: str = ""
    priceValue2: str = ""
    productDescription: str = ""
    productGroup: str = ""

    def __init__(self):
        pass

    # @staticmethod
    def get1(src):
        # origin - 19.05.2026, last edit - 19.05.2026
        res = PriceListMap()
        res.src0 = src
        res.src1 = src.replace(" ", "")
        items = res.src1.split(",")
        if (len(items) >= 1):
            res.date1 = items[0]
        return res

    def __str__(self):
        res = ""
        res = res+"src0 "+self.src0
        res = res+", src1 "+self.src1
        res = res+", defect "+self.defect
        res = res+", date1 "+self.date1
        res = res+", lastLineTitle "+self.lastLineTitle
        res = res+", productName "+self.productName
        res = res+", productUnit "+self.productUnit
        res = res+", priceValue1 "+self.priceValue1
        res = res+", priceValue2 "+self.priceValue2
        res = "{"+res+"}"
        return res

    # @staticmethod
    def test():
        # origin - 19.05.2026, last edit - 19.05.2026
        for tmp in ["35", "35,5", "35,5,6", "35,5,6,7", "35,5,6,7,8", "35,5,6,7,8,9",
                    "35,5,6,7,8,9,10", "35, 5 , 6,7 ,   8 , 9  ,  10   "]:
            print(PriceListMap.get1(tmp))


PriceListMap.test()
