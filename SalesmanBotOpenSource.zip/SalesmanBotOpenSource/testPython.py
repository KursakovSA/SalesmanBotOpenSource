print("Hello, world (from Python) ! Test passed. Python is work.")
input()
