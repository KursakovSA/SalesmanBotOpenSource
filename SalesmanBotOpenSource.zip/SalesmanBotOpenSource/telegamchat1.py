import os
from agno.agent import Agent
from agno.models.ollama import Ollama
from agno.os.interfaces.telegram import Telegram  # Нативный интерфейс Agno

# 1. Инициализируем локального агента Ollama
agent = Agent(
    name="Telegram AI Agent",
    model=Ollama(id="llama3.2"),  # Укажите вашу модель
    markdown=True,
)

# 2. Передаем агента в интерфейс Telegram
# Токен можно передать явно или через переменную окружения TELEGRAM_TOKEN
telegram_bot = Telegram(
    agent=agent,
    token=os.getenv("TELEGRAM_TOKEN", "ВАШ_ТГ_ТОКЕН_ЗДЕСЬ"),
    react_emoji="👀"  # Опционально: ставит реакцию, пока думает
)

if __name__ == "__main__":
    # Запуск встроенного polling-сервера
    print("Бот успешно запущен через Agno Telegram Interface...")
    telegram_bot.run()
